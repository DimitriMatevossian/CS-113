/**
 * Tester.java - A tester class to test out the RadixSorter class
 * 
 * @author 	Dimitri Matevossian
 * @date	11/24/17
 * 
 * Algorithm
 * - create a test array and fill it with values from 0 - 9999, since the RadixSorter class is designed to handle numbers of up to 4 digits
 * - print out the unsorted array
 * - sort the array
 * - print out the sorted array
 */

package edu.miracosta.cs113;

public class Tester
{
	public static void main(String[] args)
	{
		RadixSorter mySorter = new RadixSorter();
		int[] testArr = new int[10];
		
		//fill up test array
		for(int i = 0; i < 10; i++)
		{
			testArr[i] = (int)(Math.random() * 10000);
		}
		
		//print unsorted array
		System.out.print("unsorted: ");
		for(int i = 0; i < 10; i++)
		{
			System.out.print(testArr[i] + " ");
		}
		
		//sort array
		testArr = mySorter.sort(testArr);
		
		//print out sorted array
		System.out.print("\nsorted:   " );
		for(int i = 0; i < 10; i++)
		{
			System.out.print(testArr[i] + " ");
		}
	}
}
