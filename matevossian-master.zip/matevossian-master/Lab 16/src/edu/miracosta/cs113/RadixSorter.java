/**
 * RadixSorter.java - A class that can sort a given array using the Radix sort algorithm
 */

package edu.miracosta.cs113;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class RadixSorter 
{
	/**
	 * default constructor for the RadixSorter class
	 */
	public RadixSorter()
	{
		
	}
	
	/**
	 * sorts the given array using the Radix Sort algorithm and returns a sorted array
	 * 
	 * @param numArray	The array to be sorted
	 * @return			A sorted version of the Array
	 */
	public int[] sort(int[] numArray)
	{
		int[] result = new int[numArray.length];
		int[] bucket = new int[10];
		int digit = 0;
		int bucketAccumulator = 0;
		
		//goes through each digit of each entry in the array
		for(int digitIncrementer = 1; digitIncrementer <= 1000; digitIncrementer *= 10)
		{
			//set all values in the bucket to 0
			for(int i = 0; i < 10; i++)
			{
				bucket[i] = 0;
			}
			
			//increment the bucket values according to the current digit of the numArray values we are looking at
			for(int index = 0; index < numArray.length; index++)
			{
				digit = (int)(numArray[index] / digitIncrementer) % 10;
				bucket[digit]++;
			}
			
			//increment each value in the bucket by its preceding value
			for(int i = 0; i < 10; i++)
			{
				bucket[i] += bucketAccumulator;
				bucketAccumulator = bucket[i];
			}
			
			//use the newly incremented values in the bucket to place the numArray values in the appropriate spots in the result array
			for(int j = numArray.length - 1; j >= 0; j--)
			{
				digit = (int)(numArray[j] / digitIncrementer) % 10;
				bucket[digit]--;
				
				//System.out.println("numArray[j]: " + numArray[j] + " j: " + j + " digit: " + digit + " bucket[digit]: " + bucket[digit]);
				result[bucket[digit]] = numArray[j];
			}
			
			numArray = result;
			bucketAccumulator = 0;
			//System.out.println("Incrementer: " + digitIncrementer);
		}
		
		return result;
	}
}
