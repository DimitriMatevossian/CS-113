/**
 * Contains Text and png files that answer questions 1-5 on page 333 of the textbook
 */
/**
 * @author Dimitri Matevossian
 *
 */
package edu.miracosta.cs113;