/**
 * contains a class that will print numbers 1-100,
 * prints "Fizz" instead of any multiple of 3,
 * prints "Buzz" instead of any multiple of 5,
 * prints "Fizzbuzz" instead of any number that is a multiple of both 3 and 5
 */
/**
 * @author W7263477
 *
 */
package edu.miracosta.cs113;