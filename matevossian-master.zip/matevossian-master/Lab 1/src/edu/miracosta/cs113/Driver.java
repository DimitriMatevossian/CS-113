/**
 * Driver.java : Prints numbers 1-100, prints words at certain intervals
 * 
 * @author Dimitri Matevossian
 * @version 1.0
 *
 */

package edu.miracosta.cs113;

public class Driver 
{
    /**
     * prints the output
     * 
     * @param args command line arguments (unnused)
     */
    public static void main(String[] args)
    {
        for(int i = 1; i <= 100; i++)
        {
            if(i % 5 == 0 && i % 3 == 0)
            {
                //if the number is a multiple of 3 and 5
                System.out.println("Fizzbuzz");
            }
            else
                if(i % 3 == 0)
                {
                    //if the number is a multiple of 3
                    System.out.println("Fizz");
                }
                else
                    if(i % 5 == 0)
                    {
                        //if the number is a multiple of 5
                        System.out.println("Buzz");
                    }
                    else
                    {
                        //print the number if none of the conditions are met
                        System.out.println(i);
                    }
        }
    }
}