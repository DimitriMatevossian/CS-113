/**
 * Contains Answers to Self Check 1 & 2 pg. 371
 */
/**
 * @author W7263477
 *
 */
package edu.miracosta.cs113;