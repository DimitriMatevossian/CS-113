/**
 * MaxComparator.java - Implements the Comparator interface to compare two Integers
 * 					  - performs the comparison "backwards" so that the MaxHeap's order will be swapped
 */

package edu.miracosta.cs113;

import java.util.Comparator;

public class MaxComparator implements Comparator<Integer>
{
	/**
	 * default constructor
	 */
	public MaxComparator()
	{
		
	}
	
	/**
	 * compares the right object to the left object, to accomplish a reverse heap order in MaxHeap
	 */
	public int compare(Integer left, Integer right)
	{
		return right - left;
	}
}
