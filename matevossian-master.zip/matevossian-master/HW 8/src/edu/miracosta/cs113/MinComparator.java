/**
 * MinComparator.java - Implements the Comparator interface to compare two Integers
 * 					  - performs the comparison "normally" so that the MinHeap will maintain heap order
 */

package edu.miracosta.cs113;

import java.util.Comparator;

public class MinComparator implements Comparator<Integer>
{
	/**
	 * default constructor
	 */
	public MinComparator()
	{
		
	}
	
	/**
	 * compares the left object to the right object, to achieve heap order in MinHeap
	 */
	public int compare(Integer left, Integer right)
	{
		return left - right;
	}
}
