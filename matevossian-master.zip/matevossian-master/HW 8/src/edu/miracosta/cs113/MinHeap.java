/**
 * MinHeap.java - extends the abstract Heap<E> class
 * 				- contains a heap that upholds heap order
 */

package edu.miracosta.cs113;

import java.util.Comparator;

public class MinHeap<E> extends Heap<E>
{
	private Comparator comparator;
	
	/**
	 * default constructor that sets comparator to null
	 */
	public MinHeap()
	{
		comparator = null;
	}
	
	/**
	 * constructor that takes a comparator to use for the comparisons in the add() and remove() methods
	 * 
	 * @param comparator	Comparator to be used by the heap
	 */
	public MinHeap(Comparator comparator)
	{
		this.comparator = comparator;
	}
	
	/**
	 * checks if there is a comparator to use for the comparison
	 * 	- if comparator is null, compare the left and right objects using their natural compareTo methods
	 *  - if there is a specified comparator, use that objects compare method
	 */
	@Override
	protected int compare(E left, E right) 
	{
		if(comparator != null)
		{
			//comparator's compare()
			return comparator.compare(left,  right);
		}
		else
		{
			//natural compareTo()
			return ((Comparable<E>) left).compareTo(right);
		}
	}
}
