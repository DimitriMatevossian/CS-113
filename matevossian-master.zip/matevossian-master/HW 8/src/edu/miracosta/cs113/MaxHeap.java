/**
 * MaxHeap.java - extends the abstract Heap<E> class
 * 				- contains a heap that upholds a reverse heap order
 */

package edu.miracosta.cs113;

import java.util.Comparator;

public class MaxHeap<E> extends Heap<E>
{
	private Comparator comparator;
	
	/**
	 * default constructor that sets comparator to null
	 */
	public MaxHeap()
	{
		comparator = null;
	}
	
	/**
	 * constructor that takes a comparator to use for the comparisons in the add() and remove() methods
	 * 
	 * @param comparator	Comparator to be used by the heap
	 */
	public MaxHeap(Comparator comparator)
	{
		this.comparator = comparator;
	}
	
	/**
	 * checks if there is a comparator to use for the comparison
	 * 	- if comparator is null, compare the left and right objects using their natural compareTo methods
	 *  - if there is a specified comparator, use that objects compare method
	 */
	@Override
	protected int compare(E left, E right) 
	{
		if(comparator != null)
		{
			//comparator's compare()
			return comparator.compare(left,  right);
		}
		else
		{
			//the natural compareTo() method
			return ((Comparable<E>) left).compareTo(right);
		}
	}
}
