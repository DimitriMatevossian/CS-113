/**
 * Heap.java - an abstract class that represents a heap
 * 			 - the heap is implemented using an ArrayList
 */

package edu.miracosta.cs113;

import java.util.ArrayList;

public abstract class Heap<E>
{
	private ArrayList<E> table = new ArrayList<E>();
	
	/**
	 * compares two pieces of data in a way that depends on the subclass
	 * 
	 * @param 	data1	First piece of data being compared
	 * @param	data2	Second piece of data being compared
	 * @return	An appropriate integer resulting from the comparison
	 */
	abstract protected int compare(E data1, E data2);
	
	/**
	 * adds a piece of data to the heap, while maintaining order depending on the implementation of the compare method
	 * 
	 * @param data	The data being added
	 */
	public void add(E data)
	{
		int child = 0;
		int parent = 0;
		E temp;
		
		table.add(data);
		
		child = table.size() - 1;
		parent = (child - 1) / 2;
		
		//maintain heap order depending on the implementation of the compare method
		while(parent >= 0 && compare(table.get(parent), table.get(child)) > 1)
		{
			temp = table.get(parent);
			table.set(parent, table.get(child));
			table.set(child, temp);
			child = parent;
			parent = (child - 1) / 2;
		}
	}
	
	/**
	 * removes the smallest value (root) of the heap, while maintaining order depending on the implementation of the compare method
	 * 
	 * @return	The data that was removed
	 */
	public E remove()
	{
		int parent = 0;
		int leftChild = 1;
		int rightChild = 2;
		int minChild = 1;
		
		E removedData = table.remove(table.size() - 1);
		
		table.set(0, removedData);
		
		while(leftChild < table.size() && compare(table.get(parent), table.get(minChild)) > 0)
		{
			if(rightChild < table.size() && compare(table.get(rightChild), table.get(leftChild)) < 0)
			{
				minChild = rightChild;
			}
			
			E temp = table.get(parent);
			table.set(parent, table.get(minChild));
			table.set(minChild, temp);
			parent = minChild;
			leftChild = (2 * parent) + 1;
			rightChild = leftChild + 1;
			minChild = leftChild;
		}
		
		return removedData;
	}
	
	/**
	 * prints out each value in the heap on one line
	 */
	public void displayHeap()
	{
		for(E data : table)
		{
			System.out.print(data + " ");
		}
		
		System.out.println();
	}
}
