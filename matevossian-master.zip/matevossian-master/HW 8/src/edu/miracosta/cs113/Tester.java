/** Tester.java - A class that tests the MinHeap and MaxHeap classes
 * 
 * @author 	Dimitri Matevossian
 * @date	11/08/17
 * 
 * Algorithm
 * - create test MaxHeap and MinHeap objects
 * - add dummy values to the MaxHeap
 * - display the MaxHeap
 * - remove a value from the MaxHeap
 * - display the MaxHeap
 * - add dummy values to the MinHeap
 * - display the MinHeap
 * - remove a value from the MinHeap
 * - display the MinHeap
 */

package edu.miracosta.cs113;

public class Tester
{
	public static void main(String[] args)
	{
		MaxHeap<Integer> maxTest = new MaxHeap<Integer>(new MaxComparator());
		MinHeap<Integer> minTest = new MinHeap<Integer>(new MinComparator());
		
		System.out.println("MaxHeap Test:");
		
		//add dummy values
		maxTest.add(24);
		maxTest.add(12);
		maxTest.add(15);
		maxTest.add(4);
		maxTest.add(8);
		maxTest.add(31);
		
		//display heap
		maxTest.displayHeap();
		
		//remove a dummy value
		maxTest.remove();
		
		//display again to verify the removal
		maxTest.displayHeap();
		
		System.out.println("MinHeap Test:");
		
		//add dummy values
		minTest.add(24);
		minTest.add(12);
		minTest.add(15);
		minTest.add(4);
		minTest.add(8);
		minTest.add(31);
		
		//display heap
		minTest.displayHeap();
		
		//remove a dummy value
		minTest.remove();
		
		//display again to verify removal
		minTest.displayHeap();
	}
}
