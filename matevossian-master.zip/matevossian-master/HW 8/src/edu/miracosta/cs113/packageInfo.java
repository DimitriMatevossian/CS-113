/**
 *	- Contains an abstract Heap class that represents a Heap structure, implemented with an ArrayList
 *	- Contains a MinHeap and MaxHeap class that extend Heap, and represent heaps being kept in heap order(MinHeap) and reverse heap order(MaxHeap)
 *	- Contains a MinComparator and MaxComparator that are used to accomplish the specific comparisons needed for the MinHeap and MaxHeap classes to keep their respective orders
 *	- Contains a Tester class that tests the MinHeap and MaxHeap classes
 */
/**
 * @author Dimitri Matevossian
 *
 */
package edu.miracosta.cs113;