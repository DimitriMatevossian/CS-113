/**
 * Contains answers to:
 * 		- Self Check 1 pg. 366
 * 		- Programming 1 pg. 367
 * 		- Programming 2 pg. 367
 */
/**
 * @author W7263477
 *
 */
package edu.miracosta.cs113;