/**
 * Contains a method to check whether or not a number is a power of two
 * 
 * @author Dimitri Matevossian
 * @version 1.0
 */

package edu.miracosta.cs113;

public class PowerChecker
{
    /**
     * Constructor for objects of class PowerChecker
     */
    public PowerChecker()
    {
        
    }

    /**
     * checks if given number is a power of two or not
     * 
     * @param num   the number being checked
     * 
     * @return a boolean representing whether or not the number is a power of two
     */
    public boolean checkNum(int num)
    {   
        for(int temp = num; temp > 0; temp /= 2)
        {
             if(temp == 1)
             {
                 //if temp reaches 1, the number is a power of two
                 return true;
             }
             else
                if(temp % 2 != 0)
                {
                    //if temp becomes an odd number at any point, the number is not a power of two
                    return false;
                }
       }
       
       return false;
    }
}