/**
 * contains class that can take an integer and return a boolean representing if that integer is a power of two
 */
/**
 * @author W7263477
 *
 */
package edu.miracosta.cs113;