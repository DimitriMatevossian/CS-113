/**
 * Tester.java : tests the PowerChecker class with several cases
 * 
 * @author Dimitri Matevossian
 * @version 1.0
 *
 */

package edu.miracosta.cs113;

public class Tester 
{
    /**
     * Tests whether or not the PowerChecker can recognize numbers that are powers of 2 and those that are not
     * 
     * @param args command line arguments (unnused)
     */
    public static void main(String[] args)
    {
        PowerChecker checker = new PowerChecker();
        
        System.out.println("Testing 2: " + checker.checkNum(2));
        System.out.println("Testing 32: " + checker.checkNum(32));
        System.out.println("Testing 4: " + checker.checkNum(4));
        System.out.println("Testing 0: " + checker.checkNum(0));
        System.out.println("Testing 1: " + checker.checkNum(1));
        System.out.println("Testing -1: " + checker.checkNum(-1));
        System.out.println("Testing 524288 (2^19): " + checker.checkNum(524288));
        System.out.println("Testing 113: " + checker.checkNum(113));
    }
}