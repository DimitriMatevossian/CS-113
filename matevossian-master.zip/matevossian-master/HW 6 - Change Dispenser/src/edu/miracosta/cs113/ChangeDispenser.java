/**
 * ChangeDispenser.java - Can calculate and store all the possible combinations of how a given amount of cents
 * can be broken up into change
 */

package edu.miracosta.cs113;

import java.util.ArrayList;

public class ChangeDispenser 
{
	//will store all of the combinations
	private ArrayList<Combo> comboList = new ArrayList<Combo>();
	
	/**
	 * default constructor for the ChangeDispenser class
	 */
	public ChangeDispenser()
	{
		
	}
	
	/**
	 * wrapper method for the recursive method that calculates the possible change combinations
	 * checks for the case of the given amount being zero
	 * 
	 * @param amount	The amount of cents to be broken up into different combinations of change
	 * @return			An ArrayList containing all of the calculated combinations
	 * 					or returns an empty ArrayList if the given amount was zero
	 */
	public ArrayList<Combo> calculateChange(int amount)
	{
		comboList.clear();
		
		if(amount == 0)
		{
			//return an empty ArrayList if amount is 0
			comboList.add(new Combo());
			return comboList;
		}
		else
		{
			//call the recursive method
			calculateChange(amount, 0, 0, 0, amount);
			return comboList;
		}
	}
	
	/**
	 * recursively calculates the possible combinations of how the given amount of cents can be broken up into change
	 * 
	 * @param amount	The given amount to be broken up into different combinations of change
	 * @param q			The number of quarters in a given combination
	 * @param d			The number of dimes in a given combination
	 * @param n			The number of nickels in a given combination
	 * @param p			The number of pennies in a given combination
	 */
	private void calculateChange(int amount, int q, int d, int n, int p)
	{	
		Combo temp = new Combo(q, d, n, p);
		
		//check for duplicates before adding
		if(!comboList.contains(temp))
		{
			comboList.add(temp);
		}
		
		//recursive cases that break up the amount into certain combos
		if(p >= 5)
		{
			calculateChange(amount, q, d, n + 1, p - 5);
		}
		if(p >= 10)
		{
			calculateChange(amount, q, d + 1, n, p - 10);
		}
		if(p >= 25)
		{
			calculateChange(amount, q + 1, d, n, p - 25);
		}
	}
	
}
