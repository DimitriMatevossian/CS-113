/** 
 * Combo.java - Holds four integers pertaining to numbers of coins that combine to make up a specific amount of change
 */

package edu.miracosta.cs113;

public class Combo
{
	//the number of each coin
	private int quarters;
	private int dimes;
	private int nickels;
	private int pennies;
	
	/**
	 * default constructor for the Combo class
	 */
	public Combo()
	{
		quarters = 0;
		dimes = 0;
		nickels = 0;
		pennies = 0;
	}
	
	/**
	 * Constructor for the Combo class that initializes all coin number values
	 * 
	 * @param quarters	number of quarters
	 * @param dimes		number of dimes
	 * @param nickels	number of nickels
	 * @param pennies	number of pennies
	 */
	public Combo(int quarters, int dimes, int nickels, int pennies)
	{
		this.quarters = quarters;
		this.dimes = dimes;
		this.nickels = nickels;
		this.pennies = pennies;
	}
	
	/**
	 * returns all of the data found in this class as one organized String
	 */
	public String toString()
	{
		return "Quarters: " + quarters + " Dimes: " + dimes + " nickels: " + nickels + " pennies: " + pennies;
	}
	
	/**
	 * checks the this Combo object against another for equality using the toString() method
	 * 
	 * @param anotherCombo	The other combo Object being checked
	 */
	public boolean equals(Object anotherCombo)
	{
		anotherCombo = (Combo)anotherCombo;
		
		return this.toString().equals(anotherCombo.toString());
	}
}
