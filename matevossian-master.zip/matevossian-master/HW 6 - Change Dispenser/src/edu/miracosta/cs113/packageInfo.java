/**
 * - Contains a class that can calculate and store all the possible combinations of how a given amount of cents
 * can be broken up into change
 * - Contains another class to store those combinations
 * - Contains a tester class to test out the methods of the ChangeDispenser class
 */
/**
 * @author Dimitri Matevossian
 *
 */
package edu.miracosta.cs113;