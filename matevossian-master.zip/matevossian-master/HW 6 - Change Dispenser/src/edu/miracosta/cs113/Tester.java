/** Tester.java - A class to test the ChangeDispenser class
 * 
 * @author 	Dimitri Matevossian
 * @date	10/11/17
 * 
 * Algorithm
 * - test values 5 - 30 cents in 5 cent increments using a loop
 * - print the different combinations and # of combinations each time
 * - test the value 75 for a larger combination
 * - print all the different combinations and the # of combinations
 */

package edu.miracosta.cs113;

import java.util.ArrayList;

public class Tester
{
	public static void main(String[] args)
	{
		ChangeDispenser myDispenser = new ChangeDispenser();
		ArrayList<Combo> comboList = new ArrayList<Combo>();
		
		//test values 5 - 30 cents in 5 cent increments
		for(int testAmount = 5; testAmount <= 30; testAmount += 5)
		{
			comboList = myDispenser.calculateChange(testAmount);
			System.out.println("Testing amount: " + testAmount);
			
			//print all the different combinations
			for(int i = 0; i < comboList.size(); i++)
			{
				System.out.println(comboList.get(i));
			}
			
			//print the number of combinations
			System.out.println(comboList.size() + " combinations\n");
		}
		
		//test the value 75 for a larger combination
		comboList = myDispenser.calculateChange(75);
		System.out.println("Testing amount: 75");
		
		//print all the different combinations
		for(int i = 0; i < comboList.size(); i++)
		{
			System.out.println(comboList.get(i));
		}
		
		//print the # of combinations
		System.out.println(comboList.size() + " combinations");
	}
}
