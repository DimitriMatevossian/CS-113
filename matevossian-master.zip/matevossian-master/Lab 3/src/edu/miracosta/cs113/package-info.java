/**
 * contains a UML Diagram for Programming Project 2 on pg. 55
 */
/**
 * @author W7263477
 *
 */
package edu.miracosta.cs113;