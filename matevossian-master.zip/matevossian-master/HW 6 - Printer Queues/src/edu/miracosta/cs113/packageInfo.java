/**
 * - Contains a class representing a print Job, which holds number of pages and a registry number
 * - Contains a class that represents a Printer, which stores and processes several print Jobs from a queue
 * - Contains a PrinterQueueSystem class, which holds 3 printers, and manages the Printers receiving and processing print Jobs
 * - Contains a Tester class which tests the PrinterQueueSystem's method with random values
 */
/**
 * @author Dimitri Matevossian
 *
 */
package edu.miracosta.cs113;