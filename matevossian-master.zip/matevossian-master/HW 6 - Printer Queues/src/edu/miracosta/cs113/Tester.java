/** Tester.java - A class to test the PrinterQueueSystem class
 * 
 * @author 	Dimitri Matevossian
 * @date	10/11/17
 * 
 * Algorithm
 * - add 100 test jobs to the PrinterQueueSystem of pages randomly selected between 1 - 50 pages
 * - print out the jobs being received by the system
 * - simulate the printing of the 100 test jobs
 * - print out each job being completed
 * - print out the total time taken to complete all 100 test jobs
 */

package edu.miracosta.cs113;

public class Tester 
{
	public static void main(String[] args)
	{
		PrinterQueueSystem myOS = new PrinterQueueSystem();
		int timeElapsed;
		
		//add 100 test jobs with pages randomly selected between 1 - 50 pages
		for(int i = 0; i < 100; i++)
		{
			myOS.addPrintJob((int)(Math.random() * 50) + 1);
		}
		
		timeElapsed = myOS.simulatePrint();
		
		//print out total time taken to complete all jobs
		System.out.println("It took " + timeElapsed + " minutes to finish all print jobs.");
	}
}
