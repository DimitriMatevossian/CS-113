/**
 * Printer.java - contains methods to store and process print Jobs
 */

package edu.miracosta.cs113;

import java.util.LinkedList;
import java.util.Queue;

public class Printer 
{
	Queue<Job> jobQueue = new LinkedList<Job>();
	private int printerNum;
	
	/**
	 * default constructor for the Printer class
	 */
	public Printer()
	{
		printerNum = 0;
	}
	
	/**
	 * constructor for the Printer class that takes an ID number for the printer
	 * 
	 * @param printerNum	The ID for the printer
	 */
	public Printer(int printerNum)
	{
		this.printerNum = printerNum;
	}
	
	/**
	 * adds a print job to the queue
	 * 
	 * @param newJob	The new print job to be added
	 */
	public void addJob(Job newJob)
	{
		jobQueue.offer(newJob);
	}
	
	/**
	 * prints out a given print job and the current printer that completed it
	 * 
	 * @param currentJob	The print job to be printed out
	 */
	public void printOutJob(Job currentJob)
	{
		System.out.println("Printer #" + printerNum + " printed job #" + currentJob.getJobNum());
	}
	
	/**
	 * checks to see if the queue is empty
	 * 
	 * @return	A boolean representing whether or not the job queue is empty
	 */
	public boolean isEmpty()
	{
		return jobQueue.peek() == null;
	}
	
	/**
	 * simulates one minute passing for the printer
	 */
	public void tick()
	{
		if(!isEmpty())
		{
			if(jobQueue.peek().getNumPages() <= 10)
			{
				//print out and remove the current print job if it is going to be finished
				printOutJob(jobQueue.poll());
			}
			else
			{
				//simulates printing out 10 pages from a current job that has more than 10 pages left
				jobQueue.peek().decrementNumPages(10);
			}
		}
	}
}
