/**
 * PrinterQueueSystem.java - contains 3 Printer objects, and can take jobs and sort them to the according printers and simulate a run of the three Printers to complete all the print jobs
 */

package edu.miracosta.cs113;

import java.util.LinkedList;
import java.util.Queue;

public class PrinterQueueSystem 
{
	private Queue<Job> printQueue = new LinkedList<Job>();	//temporarily holds all the jobs to be added
	private Printer printer1 = new Printer(1);	//deals with jobs that are less than 10 pages
	private Printer printer2 = new Printer(2);	//deals with jobs that are less than 20 pages
	private Printer printer3 = new Printer(3);	//deals with jobs that are 20 or more pages
	private int totalNumJobs;
	
	/**
	 * default constructor for the PrinterQueueSystem class
	 */
	public PrinterQueueSystem()
	{
		totalNumJobs = 1;
	}
	
	/**
	 * adds a Job with the given number of pages to the printQueue
	 * 
	 * @param numPages	The number of pages the new Job will contain
	 */
	public void addPrintJob(int numPages)
	{
		Job newPrintJob = new Job(numPages, totalNumJobs);
		System.out.println("Job #" + totalNumJobs + " received: " + numPages + " pages.");
		totalNumJobs++;
		
		printQueue.add(newPrintJob);
	}
	
	/**
	 * sends the current print job to the according printer
	 * 
	 * @param newPrintJob	The new print job to be added to a printer's queue
	 */
	private void sendToPrinter(Job newPrintJob)
	{
		if(newPrintJob.getNumPages() < 10)
		{
			printer1.addJob(newPrintJob);
		}
		else
			if(newPrintJob.getNumPages() < 20)
			{
				printer2.addJob(newPrintJob);
			}
			else
			{
				printer3.addJob(newPrintJob);
			}
	}
	
	/**
	 * simulates the printers printing out each job over 1 minute intervals
	 * 
	 * @return	The total time it took to complete all given print jobs
	 */
	public int simulatePrint()
	{
		int time = 0;
		sendToPrinter(printQueue.poll());	
		
		//as long as there are any jobs in one of the printers
		while(!printer1.isEmpty() || !printer2.isEmpty() || !printer3.isEmpty())
		{
			//simulate one minute passing on each printer
			printer1.tick();
			printer2.tick();
			printer3.tick();
			
			//if there are any more jobs left in the initial queue
			if(printQueue.peek() != null)
			{
				sendToPrinter(printQueue.poll());
			}
			
			time++;
		}
		
		return time;
	}
}
