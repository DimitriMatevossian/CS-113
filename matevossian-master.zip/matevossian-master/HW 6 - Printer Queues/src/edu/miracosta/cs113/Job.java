/**
 * Job.java - represents a print job that will be sent to a Printer
 */

package edu.miracosta.cs113;

public class Job 
{
	private int numPages;
	private int jobNum;
	
	/**
	 * default constructor for the Job class
	 */
	public Job()
	{
		numPages = 0;
		jobNum = 0;
	}
	
	/**
	 * constructor for the Job class that takes the number of pages and the job number
	 * 
	 * @param numPages	The number of pages in this print job
	 * @param jobNum	The registry number of this print job
	 */
	public Job(int numPages, int jobNum)
	{
		this.numPages = numPages;
		this.jobNum = jobNum;
	}
	
	/**
	 * gets the number of pages
	 * 	
	 * @return	The number of pages in this print job
	 */
	public int getNumPages()
	{
		return numPages;
	}
	
	/**
	 * gets the print job's registry number
	 * 
	 * @return	The print job's registry number
	 */
	public int getJobNum()
	{
		return jobNum;
	}
	
	/**
	 * decrements the number of pages in the print job by the specified amount
	 * 
	 * @param value	The amount to decrement the number of pages by
	 */
	public void decrementNumPages(int value)
	{
		numPages -= value;
	}
	
	/**
	 * converts the information of this Job class to a String and returns it
	 * 
	 * @return	the information of this Job class as a String
	 */
	public String toString()
	{
		return "Number of Pages: " + numPages + " Job Number: " + jobNum;
	}
	
	/**
	 * checks whether or not this Job object is equal to another given Job object
	 * 
	 * @param anotherJob	The other Job to check against the current one
	 * @return				A boolean representing the equality of the two Job objects
	 */
	public boolean equals(Job anotherJob)
	{
		return this.toString().equals(anotherJob.toString());
	}
}
