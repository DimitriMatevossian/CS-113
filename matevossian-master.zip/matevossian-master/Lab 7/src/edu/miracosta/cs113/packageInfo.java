/**
 * Contains a StackInt interface containing methods necessary for building a stack data structure
 * Contains an ArrayStack class, which implements StackInt to create a stack using an array
 * Contains a Tester class to test out the methods in the ArrayStack class
 */
/**
 * @author Dimitri Matevossian
 *
 */
package edu.miracosta.cs113;