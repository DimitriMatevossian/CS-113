/** Tester.java - A class to test the ArrayStack class, which implements the StackInt interface
 * 
 * @author 	Dimitri Matevossian
 * @date	10/03/17
 * 
 * Algorithm
 * - push some test values onto the stack
 * - peek at the top value to verify the pushes
 * - add 9 more values to make sure the array can reallocate when it goes above the initial capacity of 10
 * - pop all of the values from the stack and print them
 * - test out the empty() method now that all values have been popped from the stack
 */

package edu.miracosta.cs113;

public class Tester 
{
	public static void main(String[] args)
	{
		ArrayStack<String> myArrayStack = new ArrayStack<String>();
		
		//push some test values onto the stack
		myArrayStack.push("Bill");
		myArrayStack.push("John");
		
		//peek at the top value to verify the pushes
		System.out.println("Peeking the top value after 2 pushes: " + myArrayStack.peek());
		
		//add 9 more values to make sure the array can reallocate when it goes above the initial capacity of 10
		myArrayStack.push("Jane");
		myArrayStack.push("Bob");
		myArrayStack.push("Dylan");
		myArrayStack.push("Lairon");
		myArrayStack.push("Golisopod");
		myArrayStack.push("Dunsparce");
		myArrayStack.push("Drampa");
		myArrayStack.push("Mantyke");
		myArrayStack.push("Cosmog");
		
		System.out.println("\nPopping and printing all values from the stack:");
		
		//pop all of the values from the stack and print them
		for(int i = 0; i < 11; i++)
		{
			System.out.println(myArrayStack.pop());
		}
		
		//test out the empty() method now that all values have been popped from the stack
		System.out.println("\nTesting the empty() method now that all values have been popped: " + myArrayStack.empty());
	}
}
