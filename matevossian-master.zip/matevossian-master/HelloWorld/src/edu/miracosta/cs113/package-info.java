/**
 * contains hello world demo to test github setup
 */
/**
 * @author W7263477
 *
 */
package edu.miracosta.cs113;