/**
 * Contains a Driver class that tests out the methods of Stack and Queue
 */
/**
 * @author Dimitri Matevossian
 *
 */
package edu.miracosta.cs113;