/** Driver.java - A class to test out the functionality of Stack and Queue
 * 
 * @author 	Dimitri Matevossian
 * @date	10/03/17
 * 
 * Algorithm
 * - fill the firstStack with values
 * - check the top of the stack
 * - move all of the elements from firstStack to secondStack and myQueue
 * - print out and remove all of the values in secondStack and myQueue
 * - extra test to make sure that secondStack was emptied out when printing all the values
 */

package edu.miracosta.cs113;

import java.util.Stack;
import java.util.LinkedList;
import java.util.Queue;

public class Driver
{
	public static void main(String[] args)
	{
		Stack<Integer> firstStack = new Stack<Integer>();
		Stack<Integer> secondStack = new Stack<Integer>();
		Queue<Integer> myQueue = new LinkedList<Integer>();
		
		//filling the firstStack with values
		firstStack.push(-1);
		firstStack.push(15);
		firstStack.push(23);
		firstStack.push(44);
		firstStack.push(4);
		firstStack.push(99);
		
		//checking the top of the stack
		System.out.println("firstStack.peek(): " + firstStack.peek() + "\n");
		
		//moving all of the elements from firstStack to secondStack and myQueue
		for(int i = 0; i < 6; i++)
		{
			secondStack.add(firstStack.peek());
			myQueue.add(firstStack.peek());
			firstStack.pop();
		}
		
		//formatting
		System.out.println("secondStack    myQueue");
		
		//print out and remove all of the values in secondStack and myQueue
		for(int i = 0; i < 6; i++)
		{
			System.out.printf("%-3d %13d\n", secondStack.pop(),  myQueue.poll());
		}
		
		//extra test to make sure that secondStack was emptied out when printing all the values
		System.out.println("\nSECOND STACK EMPTY TEST: " + secondStack.empty());
	}
}
