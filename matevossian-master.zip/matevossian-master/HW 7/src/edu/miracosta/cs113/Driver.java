/** Driver.java - A class that uses the BinaryTree class
 * 				- gives the user a menu to use the BinaryTree to decode morse code or look at all morse code values
 * 
 * @author 	Dimitri Matevossian
 * @date	10/31/17
 * 
 * Algorithm
 * - prompt the user with a menu (1, 2, 3, 4)
 * 		1) display all values from the morse code tree with the corresponding alphabetic letters
 * 		2) read in a file with the given name and display the decoded message
 * 		3) decode a given line of morse code and display the decoded message
 * 		4) exit the program
 */

package edu.miracosta.cs113;

import java.util.Scanner;

public class Driver
{
	public static void main(String[] args)
	{
		int choice = 0;
		String userFileName;
		String morseCodeLine;
		String garbage;
		Scanner keyboard = new Scanner(System.in);
		BinaryTree<String> morseCodeTree = new BinaryTree<String>("", null, null);
		morseCodeTree.readBinaryTree("morse code.txt");
		
		do
		{
			System.out.println("<1> Display all morse code letters\n<2> Decode morse code file\n<3> Decode morse code input\n<4> Exit");
			choice = keyboard.nextInt();
			garbage = keyboard.nextLine();
			
			switch (choice)
			{
				case 1:
					morseCodeTree.testMorseCode();
					break;
				case 2:
					System.out.println("Enter file name: ");
					userFileName = keyboard.nextLine();
					System.out.println(morseCodeTree.translateMorseCodeFile(userFileName));
					break;
				case 3:
					System.out.println("Enter morse code: ");
					morseCodeLine = keyboard.nextLine();
					System.out.println(morseCodeTree.translateMorseCodeLine(morseCodeLine));
					break;
				case 4:
					break;
				default:
					System.out.println("Invalid Input.");
					break;
			}
			
		} while(choice != 4);
	}
}
