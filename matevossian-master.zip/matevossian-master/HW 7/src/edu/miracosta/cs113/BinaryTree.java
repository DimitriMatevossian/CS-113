/**
 * BinaryTree.java - implements the BinaryTree data structure to make a binary tree that holds letters, ordered by morse code.
 * 				   - can also decode given morse code
 */

package edu.miracosta.cs113;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.StringTokenizer;

public class BinaryTree<E>
{
	protected Node<E> root;
	
	/**
	 * Inner node class which will make up the elements of the tree
	 */
	protected static class Node<E> implements Serializable
	{
		protected E data;
		protected Node<E> left;
		protected Node<E> right;
		
		/**
		 * constructor that takes data, and creates a node holding that data, with no left or right children
		 * 
		 * @param data	The data to be stored in the node
		 */
		public Node(E data)
		{
			this.data = data;
			this.left = null;
			this.right = null;
		}
		
		//returns the data of the node as a String
		public String toString()
		{
			return data.toString();
		}
	}
	
	/**
	 * default constructor that sets the root of the tree to null
	 */
	public BinaryTree()
	{
		root = null;
	}
	
	/**
	 * constructor that creates a new tree with the specified root
	 * is useful for recursively creating a tree
	 * 
	 * @param root	The root of the tree
	 */
	protected BinaryTree(Node<E> root)
	{
		this.root = root;
	}
	
	/**
	 * constructor that creates a node with the given data and left/right children
	 * 
	 * @param data		The data to be inserted into the new node
	 * @param leftTree	The left child of the new node
	 * @param rightTree	The right child of the new node
	 */
	public BinaryTree(E data, BinaryTree<E> leftTree, BinaryTree<E> rightTree)
	{
		root = new Node<E>(data);
		
		if(leftTree != null)
		{
			root.left = leftTree.root;
		}
		else
		{
			root.left = null;
		}
		if(rightTree != null)
		{
			root.right = rightTree.root;
		}
		else
		{
			root.right = null;
		}
	}
	
	/**
	 * creates and returns a binary tree that contains the left subtree of the root
	 * 
	 * @return	The left subtree of the root
	 */
	public BinaryTree<E> getLeftSubtree()
	{
		if(root != null && root.left != null)
		{
			return new BinaryTree(root.left);
		}
		else
		{
			return null;
		}
	}
	
	/**
	 * creates and returns a binary tree that contains the right subtree of the root
	 * 
	 * @return	The right subtree of the root
	 */
	public BinaryTree<E> getRightSubtree()
	{
		if(root != null && root.right != null)
		{
			return new BinaryTree(root.right);
		}
		else
		{
			return null;
		}
	}
	
	/**
	 * returns the data in the root of the tree
	 * 
	 * @return	The data held in the root
	 */
	public E getData()
	{
		return root.data;
	}
	
	/**
	 * checks to see if the root of the tree is a leaf or not
	 * 
	 * @return	A boolean representing whether or not the root is a leaf node
	 */
	public boolean isLeaf()
	{
		return (root.left == null && root.right == null);
	}
	
	/**
	 * converts the information held in the entire tree into a formatted String and returns it
	 */
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		preOrderTraverse(root, 1, sb);
		return sb.toString();
	}
	
	/**
	 * helper method for the toString() method
	 * traverses the tree and adds formatting to the string where necessary 
	 * 
	 * @param node	Current node being looked at
	 * @param depth	Current height of the tree
	 * @param sb	The StringBuilder, which holds the String to be returned by toString()
	 */
	private void preOrderTraverse(Node<E> node, int depth, StringBuilder sb)
	{
		for(int i = 1; i < depth; i++)
		{
			sb.append("   ");
		}
		
		if(node == null)
		{
			sb.append("null\n");
		}
		else
		{
			sb.append(node.toString() + "\n");
			preOrderTraverse(node.left, depth + 1, sb);
			preOrderTraverse(node.right, depth + 1, sb);
		}
	}
	
	/**
	 * a tester method that checks the alphabetic equivalent of each morse code value
	 * accomplishes this by checking each individual value in the tree
	 */
	public void testMorseCode()
	{
		String[] morseCodeArray = new String[26];
		
		morseCodeArray[0] = "*";
		morseCodeArray[1] = "-";
		morseCodeArray[2] = "**";
		morseCodeArray[3] = "*-";
		morseCodeArray[4] = "-*";
		morseCodeArray[5] = "--";
		morseCodeArray[6] = "***";
		morseCodeArray[7] = "**-";
		morseCodeArray[8] = "*-*";
		morseCodeArray[9] = "*--";
		morseCodeArray[10] = "-**";
		morseCodeArray[11] = "-*-";
		morseCodeArray[12] = "--*";
		morseCodeArray[13] = "---";
		morseCodeArray[14] = "****";
		morseCodeArray[15] = "***-";
		morseCodeArray[16] = "**-*";
		morseCodeArray[17] = "*-**";
		morseCodeArray[18] = "*--*";
		morseCodeArray[19] = "*---";
		morseCodeArray[20] = "-***";
		morseCodeArray[21] = "-**-";
		morseCodeArray[22] = "-*-*";
		morseCodeArray[23] = "-*--";
		morseCodeArray[24] = "--**";
		morseCodeArray[25] = "--*-";
		
		for(int i = 0; i < 26; i++)
		{
			System.out.printf("%5s %-2s\n", morseCodeArray[i], decodeLetter(morseCodeArray[i]));
		}
	}
	
	/**
	 * translates a morse code letter into an alphabetic letter
	 * 
	 * @param morseCode	The morse code to be decoded
	 * @return			The translated alphabetic letter
	 */
	public String decodeLetter(String morseCode)
	{
		Node<E> currentRoot = root;
		
		//goes through the entire String representing the morse code
		while(morseCode.length() > 0)
		{
			if(morseCode.charAt(0) == '*')
			{
				//go left if the current character is a "*"
				currentRoot = currentRoot.left;
			}
			else
			{
				//go right if the current character is a "-"
				currentRoot = currentRoot.right;
			}
			
			//move on to the next part of the code
			morseCode = morseCode.substring(1);
		}
		
		return currentRoot.toString();
	}
	
	/**
	 * reads in a file containing all letters in the alphabet, along with their corresponding morse code
	 * the information in the file is ordered from least complicated morse code value to mose
	 * ie: a morse code value with more characters is more complicated than one with less
	 * 
	 * @param fileName
	 * @return
	 */
	public BinaryTree<E> readBinaryTree(String fileName)
	{
		FileInputStream inputStream = null;
		Scanner fileIn;
		String letter;
		String morseCode;
		
		//read in the file
		try 
		{
            // Can we open the file?
            inputStream = new FileInputStream(fileName) ;
        }
        catch (FileNotFoundException e)
		{
            // File is missing, so print an error and stop
            System.out.println("File not found.\nExiting program.") ;
            System.exit(0) ;
        }
        fileIn = new Scanner(inputStream);
        try
        {
            while(fileIn.hasNextLine())
            {
                //will separate each token with a " "
                fileIn.useDelimiter("\\s");
                letter = fileIn.next();
                morseCode = fileIn.next();
                
                //add an alphabetic letter to the tree with a position based off of its morse code value
                morseCodeAdd(morseCode, new Node<E>((E)letter));
                
                fileIn.nextLine();
            }
            
            inputStream.close();
            fileIn.close();
        }
        catch (IOException e)
        {
            //if we cannot read from a certain line
            System.out.println("Error\nExiting program.") ;
            System.exit(0) ;
        }
        catch(InputMismatchException e)
        {
            System.out.println("Input Error\nExiting program.") ;
            System.exit(0) ;
        }

        return new BinaryTree<E>(root);
	}
	
	/**
	 * adds the given node containing an alphabetic letter to the tree
	 * the position of the new node is determined by the given morse code value
	 * 
	 * @param morseCode	Morse code value that determines the location of the node to be added
	 * @param newNode	New node to be added containing an alphabetic letter corresponding to the morse code value
	 */
	public void morseCodeAdd(String morseCode, Node<E> newNode)
	{
		Node<E> currentRoot = root;
		
		while(morseCode.length() > 0)
		{
			if(morseCode.charAt(0) == '*')
			{
				//go left
				if(currentRoot.left == null)
				{
					//if we found a spot to add at, add the node
					currentRoot.left = newNode;
				}
				else
				{
					//otherwise keep moving through the tree
					currentRoot = currentRoot.left;
				}
			}
			else
			{
				//go right
				if(currentRoot.right == null)
				{
					//if we found a spot to add at, add the node
					currentRoot.right = newNode;
				}
				else
				{
					//otherwise keep moving through the tree
					currentRoot = currentRoot.right;
				}
			}
			
			//increment to the next character in the morse code
			morseCode = morseCode.substring(1);
		}
	}
	
	/**
	 * reads in a file with the given name and translates the line of morse code found in the file to alphabetic letters
	 * 
	 * @param fileName	The name of the file to be reading in from
	 * @return			The decoded word from the file
	 */
	public String translateMorseCodeFile(String fileName)
	{
		FileInputStream inputStream = null;
		Scanner fileIn;
		String result = "";
		String morseCode;
		
		try 
		{
            // Can we open the file?
            inputStream = new FileInputStream(fileName) ;
        }
        catch (FileNotFoundException e)
		{
            // File is missing, so print an error and stop
            System.out.println("File not found.\nExiting program.") ;
            System.exit(0) ;
        }
        fileIn = new Scanner(inputStream);
        try
        {
            while(fileIn.hasNext())
            {
                //will separate each token with a " "
                fileIn.useDelimiter("\\s");
                morseCode = fileIn.next();
                result += decodeLetter(morseCode);
            }
            
            inputStream.close();
            fileIn.close();
        }
        catch (IOException e)
        {
            //if we cannot read from a certain line
            System.out.println("Error\nExiting program.") ;
            System.exit(0) ;
        }
        catch(InputMismatchException e)
        {
            System.out.println("Input Error\nExiting program.") ;
            System.exit(0) ;
        }
        
        return result;
	}
	
	/**
	 * translates a given line of morse code to a word in alphabetic letters
	 * 
	 * @param line	The line of morse code to be translated
	 * @return		The decoded word from the line
	 */
	public String translateMorseCodeLine(String line)
	{
		String result = "";
		StringTokenizer tokenizer = new StringTokenizer(line);
				
		while(tokenizer.hasMoreTokens())
		{
			result += decodeLetter(tokenizer.nextToken());
		}
		
		return result;
	}
}
