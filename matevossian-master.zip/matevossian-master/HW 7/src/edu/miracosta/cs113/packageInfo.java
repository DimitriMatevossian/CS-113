/**
 * Contains a BinaryTree class which implements the BinaryTree data structure to make a binary tree that holds letters, ordered by morse code; can also decode given morse code
 * Contains a Driver class which gives the user a menu to use the BinaryTree to decode morse code or look at all morse code values
 */
/**
 * @author Dimitri Matevossian
 *
 */
package edu.miracosta.cs113;