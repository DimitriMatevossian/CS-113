/**
 * Solver.java : Solves the clue problem in 20 or less theories
 * 
 * @author Dimitri Matevossian
 * @version 1.0
 *
 */

package edu.miracosta.cs113;

import java.util.Scanner;

public class Solver 
{
    /**
     * Solver for the clue problem
     * 
     * @param args command line arguments (unused)
     */
    public static void main(String[] args)
    {
        int answerSet, solution, murderer = 1, weapon = 1, location = 1;
        Scanner keyboard = new Scanner(System.in);
        Theory answer = null;
        AssistantJack jack;
        
        //prompt the user for a theory to use
        System.out.print("Which theory would like you like to test? (1, 2, 3[random]): ");
		answerSet = keyboard.nextInt();
		keyboard.close();

		jack = new AssistantJack(answerSet);

        do
        {
            //check the current weapon, location, and murderer as the correct solution
            solution = jack.checkAnswer(weapon, location, murderer);
            
            if(solution == 1)
            {
                //weapon was wrong
                //move on to next weapon
                weapon++;
            }
            else
                if(solution == 2)
                {
                    //location was wrong
                    //move on to next location
                    location++;
                }
                else
                {
                    //murderer was wrong
                    //move on to next murderer
                    murderer++;
                }
        } while (solution != 0);
        
        //print out correct answer and number of tries to user
        answer = new Theory(weapon, location, murderer);
        System.out.println("Total Checks = " + jack.getTimesAsked() + ", Solution = " + answer);

        if (jack.getTimesAsked() > 20) {
            System.out.println("FAILED!! You're a horrible Detective...");
        } else {
            System.out.println("WOW! You might as well be called Batman!");
        }
    }
}