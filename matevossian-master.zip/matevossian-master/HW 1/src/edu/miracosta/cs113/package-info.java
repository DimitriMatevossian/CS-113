/**
 * Contains a class that solves the clue problem in 20 or less tries
 * along with the classes required to run the clue problem
 */
/**
 * @author W7263477
 *
 */
package edu.miracosta.cs113;