package edu.miracosta.cs113;

/**
 * compares the values of y1 and y2 in their respective expressions
 * for values of n up to 100 in increments of 10
 * 
 * @author W7263477
 *
 */
public class Driver 
{
	public static void main(String args[])
	{
		int y1 = 0, y2 = 0;
		
		System.out.println("y1    y2");
		
		for(int n = 0; n < 100; n++)
		{
			y1 = 100 * n + 10;
			y2 = 5 * n * n + 2;
			
			if(n % 10 == 0)
			{
				System.out.printf("%-5d %-5d\n", y1, y2);
			}
		}
	}
}
