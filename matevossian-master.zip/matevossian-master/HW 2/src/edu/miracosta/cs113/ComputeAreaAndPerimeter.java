package edu.miracosta.cs113;
import java.util.Scanner;

/**
 * Computes the area and perimeter of selected figures.
 * @author W7263477 (Original Version by Koffman and Wolfgang)
 *
 */

public class ComputeAreaAndPerimeter
{
	/** The main program performs the following steps.
	 * 1. It asks the user for the type of figure.
	 * 2. It asks the user for the characteristics of that figure.
	 * 3. It computes the perimeter.
	 * 4. It computes the area.
	 * 5. It displays the result.
	 * @param args The command line arguments -- not used
	 */
	public static void main(String args[])
	{
		Shape myShape;
		double perimeter;
		double area;
		myShape = getShape();
		myShape.readShapeData();
		perimeter = myShape.computePerimeter();
		area = myShape.computeArea();
		displayResult(myShape, area, perimeter);
		System.exit(0);
	}
	

	/** Ask the user for the type of figure.
	 *  @return An instance of the selected shape
 	 */
	public static Shape getShape()
	{
		Scanner in = new Scanner(System.in);
		System.out.println("Enter S for square");
		System.out.println("Enter T for equilateral triangle");
		String figType = in.next();
		
		if(figType.equalsIgnoreCase("s"))
		{
			return new Square();
		}
		else
			if(figType.equalsIgnoreCase("t"))
			{
				return new EquilateralTriangle();
			}
			else
			{
				return null;
			}
	}
	
	/** Display the result of the computation.
	 * @param area The area of the figure
	 * @param perim The perimeter of the figure
	 */
	private static void displayResult(Shape myShape, double area, double perim)
	{
		System.out.println(myShape);
		System.out.printf("The area is %.2f%nThe perimeter is %.2f%n", area, perim);
	}
}
