/**
 * contains UML diagram for home stereo system
 * contains sequence diagram for Github repositories
 * contains Big-O Notation problem solutions
 * contains classes Square and EquilateralTriangle that add to the figures project
 * contains a modified ComputeAreaAndPerimeter class to accomodate for the new Square and EquilateralTriangle classes
 */
/**
 * @author W7263477
 *
 */
package edu.miracosta.cs113;