package edu.miracosta.cs113;
import java.util.Scanner;

/** Represents an equilateral triangle
 *  extends Shape.
 */

public class EquilateralTriangle extends Shape
{
	// Data Fields
		/** The length of a side of the equilateral triangle */
		private double length;
		
		//Constructors
		public EquilateralTriangle()
		{
			super("Equilateral Triangle");
		}
		
		/** Constructs an equilateral triangle of the specified size.
		 * 
		 * @param length  the length
		 */
		public EquilateralTriangle(double length)
		{
			super("Equilateral Triangle");
			this.length = length;
		}
		
		//Methods
		/** Get the length.
		 * @return The length
		 */
		public double getLength()
		{
			return length;
		}
		
		/** Compute the perimeter
		 * @return The perimeter of the equilateral triangle
		 */
		@Override
		public double computePerimeter()
		{
			return length * 3;
		}
		
		/** Compute the area
		 * @return The area of the equilateral triangle
		 */
		@Override
		public double computeArea()
		{
			return (Math.pow(3, .5) / 4) * (length * length);
		}
		
		/** Read the attributes of the equilateral triangle. */
		@Override
		public void readShapeData()
		{
			Scanner in = new Scanner(System.in);
			System.out.println("Enter the length of a side of the Equilateral Triangle: ");
			length = in.nextDouble();
		}
		
		/** Create a string representation of the equilateral triangle.
		 * @return A string representation of the equilateral triangle
		 */
		@Override
		public String toString()
		{
			return super.toString() + ": length is " + length;
		}
}
