package edu.miracosta.cs113;
import java.util.Scanner;

/** Represents a square
 *  extends Shape.
 */

public class Square extends Shape
{
	// Data Fields
	/** The length of a side of the square */
	private double length;
	
	//Constructors
	public Square()
	{
		super("Square");
	}
	
	/** Constructs a square of the specified size.
	 * 
	 * @param length  the length
	 */
	public Square(double length)
	{
		super("Square");
		this.length = length;
	}
	
	//Methods
	/** Get the length.
	 * @return The length
	 */
	public double getLength()
	{
		return length;
	}
	
	/** Compute the perimeter
	 * @return The perimeter of the square
	 */
	@Override
	public double computePerimeter()
	{
		return length * 4;
	}
	
	/** Compute the area
	 * @return The area of the square
	 */
	@Override
	public double computeArea()
	{
		return length * length;
	}
	
	/** Read the attributes of the Square. */
	@Override
	public void readShapeData()
	{
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the length of a side of the Square: ");
		length = in.nextDouble();
	}
	
	/** Create a string representation of the square.
	 * @return A string representation of the square
	 */
	@Override
	public String toString()
	{
		return super.toString() + ": length is " + length;
	}
}
