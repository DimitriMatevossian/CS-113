/** 
 * PalindromeFinder.java - Can check if a given String is a palindrome by splitting the String up into two stack and checking equality
 */

package edu.miracosta.cs113;

public class PalindromeFinder
{
	private ArrayStack<String> firstHalf = new ArrayStack<String>();
	private ArrayStack<String> secondHalf = new ArrayStack<String>();
	
	/**
	 * default constructor for the PalindromeFinder class
	 */
	public PalindromeFinder()
	{
		
	}
	
	/** returns true if the subject String given is a palindrome and false otherwise (is not case sensitive)
	 * 
	 * @param subject
	 * @return	true if subject is a palindrome
	 */
	public boolean isPalindrome(String subject)
	{
		if(subject.length() == 0)
		{
			return false;
		}
		
		//splits the string into two stacks and adjusts for any upper or lower case
		split(subject.toLowerCase());
		
		//check equality of the stacks
		for(int i = 0; i < subject.length() / 2; i++)
		{
			if(!firstHalf.pop().equals(secondHalf.pop()))
			{
				return false;
			}
		}
		
		return true;
	}
	
	public void split(String subject)
	{
		int middle = 0;
		
		//if the length of the string is odd
		if(subject.length() % 2 != 0)
		{
			//ignore the middle character of the string
			middle = (subject.length() / 2) + 1;
			
			//push the first half of the string onto the first stack
			for(int i = 0; i < middle - 1; i++)
			{
				firstHalf.push(subject.substring(i, i + 1));
			}
			
			//push the second half of the string onto the second stack
			for(int i =subject.length() - 1; i >= middle; i--)
			{
				secondHalf.push(subject.substring(i, i + 1));
			}
		}
		else
		{
			middle = (subject.length() / 2);
			
			//push the first half of the string onto the first stack
			for(int i = 0; i < middle; i++)
			{
				firstHalf.push(subject.substring(i, i + 1));
			}
			
			//push the second half of the string onto the second stack
			for(int i =subject.length() - 1; i >= middle; i--)
			{
				secondHalf.push(subject.substring(i, i + 1));
			}
		}
	}
}
