/**
 * Contains a StackInt interface containing methods necessary for building a stack data structure
 * Contains an ArrayStack class, which implements StackInt to create a stack using an array
 * Contains a class that will check if the given String is a palindrome or not
 * Contains a tester method to test out the methods of the PalindromeFinder class
 */
/**
 * @author Dimitri Matevossian
 *
 */
package edu.miracosta.cs113;