/** Tester.java - A class to test the PalindromeFinder class, which uses the ArrayStack class
 * 
 * @author 	Dimitri Matevossian
 * @date	10/03/17
 * 
 * Algorithm
 * - test several Strings for palindromes
 * 		- normal palindrome
 * 		- palindrome with capital letters spread throughout the String
 * 		- different normal palindrome
 * 		- different palindrome with capital letters spread throughout the String
 * 		- non palindrome String
 * 		- palindrome with a space in it
 * 		- non palindrome with a space in it
 * 		- empty string
 */

package edu.miracosta.cs113;

public class Tester 
{
	public static void main(String[] args)
	{
		PalindromeFinder myPalFinder = new PalindromeFinder();
		
		System.out.println(myPalFinder.isPalindrome("radar"));
		System.out.println(myPalFinder.isPalindrome("RadAr"));
		System.out.println(myPalFinder.isPalindrome("abba"));
		System.out.println(myPalFinder.isPalindrome("AbBa"));
		System.out.println(myPalFinder.isPalindrome("steve"));
		System.out.println(myPalFinder.isPalindrome("abba abba"));
		System.out.println(myPalFinder.isPalindrome("steve likes pizza"));
		System.out.println(myPalFinder.isPalindrome(""));
	}
}
