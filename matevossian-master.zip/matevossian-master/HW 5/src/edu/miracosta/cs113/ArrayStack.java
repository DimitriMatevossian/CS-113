/** 
 * ArrayStack.java - a class representing a stack that uses an array to hold its data
 */

package edu.miracosta.cs113;

import java.util.EmptyStackException;

public class ArrayStack<String> implements StackInt<String>
{
	private static final int INITIAL_CAPACITY = 10;
	private String[] theData;
	private int topOfStack = -1;
	
	/**
	 * constructor for the ArrayStack class
	 */
	@SuppressWarnings("unchecked")
	public ArrayStack()
	{
		theData = (String[])new Object[INITIAL_CAPACITY];
	}
	
	/** Insert a new item on top of the stack.
	 * post: 	The new item is the top item on the stack.
	 * 			All other items are on position lower.
	 * @param	obj	The item to be inserted
	 * @return	The item that was inserted
	 */
	@Override
	public String push(String obj)
	{
		//if the stack is full
		if(topOfStack == theData.length - 1)
		{
			reallocate();
		}
		
		topOfStack++;
		theData[topOfStack] = obj;
		return obj;
	}
	
	/** Remove and return the top item on the stack.
	 * pre:		The stack is not empty.
	 * post:	The top item on the stack has been removed and the stack is oneitem smaller.
	 * @return	The top item on the stack
	 * @throws	EmptyStackException if the stack is empty
	 */
	@Override
	public String pop()
	{
		if(empty())
		{
			throw new EmptyStackException();
		}
		
		return theData[topOfStack--];
	}
	
	/** Returns the object at the top of the stack and removes it.
	 * post:	The stack is on item smaller.
	 * @return	The object at the top of the stack
	 * @throws	EmptyStackException if stack is empty
	 */
	@Override
	public String peek()
	{
		if(empty())
		{
			throw new EmptyStackException();
		}
		
		return theData[topOfStack];
	}
	
	/** Returns true if the stack is empty; otherwise returns false
	 * @return	true if the stack is empty
	 */
	@Override
	public boolean empty()
	{
		return topOfStack == -1;
	}
	
	/**
	 *  Reallocates the current Array into another that is twice as large
	 */
	private void reallocate()
	{
		String[] temp = (String[])new Object[theData.length * 2];
		
		for(int i = 0; i < theData.length; i++)
		{
			temp[i] = theData[i];
		}
		
		theData = temp;
	}
}
