/**
 * BinarySearchTreeWithRotate.java - A class that extends the BinarySearchTree Class and adds the rotateLeft and rotateRight methods
 */

package edu.miracosta.cs113;

public class BinarySearchTreeWithRotate<E extends Comparable<E>> extends BinarySearchTree<E>
{
	/**
	 * default constructor
	 */
	public BinarySearchTreeWithRotate()
	{
		
	}
	
	/**
	 * rotates left around the given node
	 * 
	 * @param center	The given node to rotate around
	 * @return			The updated node after the rotation has been performed
	 */
	protected Node<E> rotateLeft(Node<E> center)
	{
		//store the right child of the node and the left child of node's right child so that we don't lose them
		Node<E> rightChild = center.right;
		Node<E> rightLeftChild = rightChild.left;
		
		//rotate the nodes
		center.right = rightLeftChild;
		rightChild.left = center;
		center = rightChild;
		
		return center;
	}
	
	/**
	 * rotates right around the given node
	 * 
	 * @param center	The given node to rotate around
	 * @return			The updated node after the rotation has been performed
	 */
	protected Node<E> rotateRight(Node<E> center)
	{
		//store the left child of the node and the right child of node's left child so that we don't lose them
		Node<E> leftChild = center.left;
		Node<E> leftRightChild = leftChild.right;
		
		//rotate the nodes
		center.left = leftRightChild;
		leftChild.right = center;
		center = leftChild;
		
		return center;
	}
}
