/**
 * BinaryTree.java - A class that represents a Binary Tree data structure
 */

package edu.miracosta.cs113;

import java.io.Serializable;

public class BinaryTree<E extends Comparable<E>>
{
	protected Node<E> root;
	
	/**
	 * Inner node class which will make up the elements of the tree
	 */
	protected static class Node<E extends Comparable<E>>
	{
		protected E data;
		protected Node<E> left;
		protected Node<E> right;
		
		/**
		 * constructor that takes data, and creates a node holding that data, with no left or right children
		 * 
		 * @param data	The data to be stored in the node
		 */
		public Node(E data)
		{
			this.data = data;
			this.left = null;
			this.right = null;
		}
		
		//returns the data of the node as a String
		public String toString()
		{
			return data.toString();
		}
	}
	
	/**
	 * default constructor that sets the root of the tree to null
	 */
	public BinaryTree()
	{
		root = null;
	}
	
	/**
	 * constructor that creates a new tree with the specified root
	 * is useful for recursively creating a tree
	 * 
	 * @param root	The root of the tree
	 */
	protected BinaryTree(Node<E> root)
	{
		this.root = root;
	}
	
	/**
	 * constructor that creates a node with the given data and left/right children
	 * 
	 * @param data		The data to be inserted into the new node
	 * @param leftTree	The left child of the new node
	 * @param rightTree	The right child of the new node
	 */
	public BinaryTree(E data, BinaryTree<E> leftTree, BinaryTree<E> rightTree)
	{
		root = new Node<E>(data);
		
		if(leftTree != null)
		{
			root.left = leftTree.root;
		}
		else
		{
			root.left = null;
		}
		if(rightTree != null)
		{
			root.right = rightTree.root;
		}
		else
		{
			root.right = null;
		}
	}
	
	/**
	 * creates and returns a binary tree that contains the left subtree of the root
	 * 
	 * @return	The left subtree of the root
	 */
	public BinaryTree<E> getLeftSubtree()
	{
		if(root != null && root.left != null)
		{
			return new BinaryTree(root.left);
		}
		else
		{
			return null;
		}
	}
	
	/**
	 * creates and returns a binary tree that contains the right subtree of the root
	 * 
	 * @return	The right subtree of the root
	 */
	public BinaryTree<E> getRightSubtree()
	{
		if(root != null && root.right != null)
		{
			return new BinaryTree(root.right);
		}
		else
		{
			return null;
		}
	}
	
	/**
	 * returns the data in the root of the tree
	 * 
	 * @return	The data held in the root
	 */
	public E getData()
	{
		return root.data;
	}
	
	/**
	 * checks to see if the root of the tree is a leaf or not
	 * 
	 * @return	A boolean representing whether or not the root is a leaf node
	 */
	public boolean isLeaf()
	{
		return (root.left == null && root.right == null);
	}
	
	/**
	 * converts the information held in the entire tree into a formatted String and returns it
	 */
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		preOrderTraverse(root, 1, sb);
		return sb.toString();
	}
	
	/**
	 * helper method for the toString() method
	 * traverses the tree and adds formatting to the string where necessary 
	 * 
	 * @param node	Current node being looked at
	 * @param depth	Current height of the tree
	 * @param sb	The StringBuilder, which holds the String to be returned by toString()
	 */
	private void preOrderTraverse(Node<E> node, int depth, StringBuilder sb)
	{
		for(int i = 1; i < depth; i++)
		{
			sb.append("   ");
		}
		
		if(node == null)
		{
			sb.append("null\n");
		}
		else
		{
			sb.append(node.toString() + "\n");
			preOrderTraverse(node.left, depth + 1, sb);
			preOrderTraverse(node.right, depth + 1, sb);
		}
	}
}
