/**
 * BinarySearchTree.java - inherits from the BinaryTree class and adds new functionalities
 */
package edu.miracosta.cs113;

public class BinarySearchTree<E extends Comparable<E>> extends BinaryTree<E>
{
	protected boolean addReturn;
	protected boolean deleteReturn;
	
	/**
	 * default constructor
	 */
	public BinarySearchTree()
	{
		addReturn = false;
		deleteReturn = false;
	}
	
	/**
	 * starter method to the add method
	 * 
	 * @param item	Object to be added
	 * @return		True if the item was added successfully or false otherwise
	 */
	public boolean add(E item)
	{
		root = add(root, item);
		return addReturn;
	}
	
	/**
	 * The recursive portion of the add method
	 * 
	 * @param localRoot	The current node we are looking at
	 * @param item		The object to be added
	 * @return			The current Node we added at
	 */
	private Node<E> add(Node<E> localRoot, E item)
	{
		//base case: if we have found a spot to add to
		if(localRoot == null)
		{
			addReturn = true;
			return new Node<E>(item);
		}
		//if the object we are trying to add already exists in the tree
		else if(item.compareTo(localRoot.data) == 0)
		{
			addReturn = false;
			return localRoot;
		}
			//if the object is smaller than what we are currently looking at
			else if(item.compareTo(localRoot.data) < 0)
			{
				localRoot.left = add(localRoot.left, item);
			}
				//if the object is larger than what we are currently looking at
				else
				{
					localRoot.right = add(localRoot.right, item);
					return localRoot;
				}
		
		//to satisfy compiler
		return localRoot;
	}
	
	/**
	 * starter method to the find method that searches for a given target in the tree and returns it
	 * 
	 * @param target	The given target to search for
	 * @return			The data that was found, or null if the search failed
	 */
	public E find(E target)
	{
		return find(root, target);
	}
	
	/**
	 * The recursive portion of the find method
	 * 
	 * @param localRoot	The current node that we are looking at
	 * @param target	The target that we are searching for
	 * @return			The data that was found, or null if the search failed
	 */
	private E find(Node<E> localRoot, E target)
	{
		//we failed to find the target
		if(localRoot == null)
		{
			return null;
		}
		
		int compResult = (target).compareTo(localRoot.data);
		
		//we found the target
		if(compResult == 0)
		{
			return localRoot.data;
		}
		//the current node's data is larger than the target
		else if(compResult < 0)
			{
				return find(localRoot.left, target);
			}
			//the current node's data is smaller than the target
			else
			{
				return find(localRoot.right, target);
			}
	}
	
	/**
	 * searches for the given target in the tree and returns a boolean representing whether or not it was found
	 * 
	 * @param target	The target being searched for
	 * @return			A boolean representing whether or not it was found
	 */
	public boolean contains(E target)
	{
		if(find(target) != null)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
