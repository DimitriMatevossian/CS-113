package edu.miracosta.cs113;

public class AVLTester 
{
	public static void main(String[] args)
	{
		AVLTree<Integer> myTree = new AVLTree<Integer>();
		
		myTree.addItem(new Integer(2));
		
		System.out.println(myTree);
	}
}