/**
 * - Contains AVLTree.java - A class that inherits from from the BinarySearchTreeWithRotate class
 * 						 - is a self balancing tree (AVL Tree)
 * - Contains BinarySearchTree.java - inherits from the BinaryTree class and adds new functionalities
 * - Contains BinarySearchTreeWithRotate.java - A class that extends the BinarySearchTree Class and adds the rotateLeft and rotateRight methods
 * - Contains BinaryTree.java - A class that represents a Binary Tree data structure
 */
/**
 * @author W7263477
 *
 */
package edu.miracosta.cs113;