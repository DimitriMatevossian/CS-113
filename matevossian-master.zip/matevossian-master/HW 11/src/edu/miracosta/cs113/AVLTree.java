/**
 * AVLTree.java - A class that inherits from from the BinarySearchTreeWithRotate class
 * 				- is a self balancing tree (AVL Tree)
 */

package edu.miracosta.cs113;

public class AVLTree<E extends Comparable<E>> extends BinarySearchTreeWithRotate
{
	private boolean increase;
	
	/**
	 * Inner node class which will make up the elements of the tree
	 * Contains a balance instance variable which represents how balanced the AVLTree is from that node
	 */
	protected class AVLNode<E extends Comparable<E>> extends Node<E>
	{
		protected E data;
		protected Node<E> left;
		protected Node<E> right;
		private int balance;
		private static final int LEFT_HEAVY = -1;
		private static final int RIGHT_HEAVY = 1;
		private static final int BALANCED = 0;
		
		/**
		 * constructor that takes data, and creates a node holding that data, with no left or right children
		 * 
		 * @param data	The data to be stored in the node
		 */
		public AVLNode(E data)
		{
			super(data);
			this.balance = 0;
		}
		
		//returns the data of the node as a String
		public String toString()
		{
			return data.toString();
		}
	}

	/** Recursive add method. Inserts the given object into the tree.
	 *	post: addReturn is set true if the item is inserted,
	 *	false if the item is already in the tree.
	 *	@param localRoot The local root of the subtree
	 *	@param item The object to be inserted
	 *	@return The new local root of the subtree with the item
	 *	inserted
	 */
	public boolean addItem(E item)
	{
		increase = false;
		root = addItem((AVLNode<E>)root, item);
		return addReturn;
	}
	
	/**
	 * recursive portion of the addItem method
	 * 
	 * @param localRoot	The current root(node) we are looking at
	 * @param item		The item to be added into the tree
	 * @return			A node to represent the root of the tree
	 */
	private AVLNode<E> addItem(AVLNode<E> localRoot, E item)
	{
		if(localRoot == null)
		{
			addReturn = true;
			increase = true;
			return new AVLNode<E>(item);
		}
		if(item.compareTo(localRoot.data) == 0)
		{
			increase = false;
			addReturn = false;
			return localRoot;
		}
		else if(item.compareTo(localRoot.data) < 0)
		{
			//hold onto the localRoot's left node
			localRoot.left = addItem((AVLNode<E>)localRoot.left, item);
			
			if(increase)
			{
				//decrements the balance of localRoot to keep the balance of the tree updated
				decrementBalance(localRoot);
				if(localRoot.balance < AVLNode.LEFT_HEAVY)
				{
					increase = false;
					return rebalanceLeft(localRoot);
				}
			}
		}
		else if(item.compareTo(localRoot.data) > 0)
		{
			//hold onto the localRoot's right node
			localRoot.right = addItem((AVLNode<E>)localRoot.right, item);
			
			if(increase)
			{
				//increments the balance of localRoot to keep the balance of the tree updated
				incrementBalance(localRoot);
				if(localRoot.balance > AVLNode.RIGHT_HEAVY)
				{
					increase = false;
					return rebalanceRight(localRoot);
				}
			}
		}
		
		//to satisfy compiler
		return localRoot;
	}
	
	/**
	 * decrements the balance of the given AVLNode
	 * 
	 * @param node	The AVLNode to have its balance decremented
	 */
	private void decrementBalance(AVLNode<E> node)
	{
		node.balance--;
		
		if(node.balance == AVLNode.BALANCED)
		{
			//If now balanced, the overall height of the subtree hasn't changed
			increase = false;
		}
	}
	
	/**
	 * increments the balance of the given AVLNode
	 * 
	 * @param node	The AVLNode to have its balance incremented
	 */
	private void incrementBalance(AVLNode<E> node)
	{
		node.balance++;
		
		if(node.balance == AVLNode.BALANCED)
		{
			//If now balanced, the overall height of the subtree hasn't changed
			increase = false;
		}
	}
	
	/**
	 * performs a left rebalancing about the given AVLNode
	 * 
	 * @param localRoot	The node that we are rebalancing around
	 * @return			The correct rotation of the node
	 */
	private AVLNode<E> rebalanceLeft(AVLNode<E> localRoot)
	{
		//keep track of localRoot's left node
		AVLNode<E> leftNode = (AVLNode<E>)localRoot.left;
		
		//if the left node is right heavy
		if(leftNode.balance > AVLNode.BALANCED)
		{
			//the right node of the localRoot's left node
			AVLNode<E> leftRightNode = (AVLNode<E>)leftNode.right;
			
			//if the leftRight node is left heavy
			if(leftRightNode.balance < AVLNode.BALANCED)
			{
				incrementBalance(leftRightNode);
				incrementBalance(localRoot);
			}
			//if the leftRight node is right heavy
			else if(leftRightNode.balance > AVLNode.BALANCED)
			{
				decrementBalance(leftRightNode);
				decrementBalance(leftNode);
			}
			
			//update the balance of the node
			decrementBalance(leftNode);
			
			//rotate the node left and update the balance
			localRoot.left = rotateLeft(localRoot.left);
			incrementBalance(localRoot);
			incrementBalance(localRoot);
			
			//returns the right rotation about the originally given node
			return (AVLTree<E>.AVLNode<E>)rotateRight(localRoot);
		}
		else
		{
			//update the balances
			incrementBalance(leftNode);
			incrementBalance(localRoot);
			incrementBalance(localRoot);
			
			//returns the right rotation about the originally given node
			return (AVLTree<E>.AVLNode<E>)rotateRight(localRoot);
		}
	}
	
	/**
	 * performs a right rebalancing about the given AVLNode
	 * 
	 * @param localRoot	The node that we are rebalancing around
	 * @return			The correct rotation of the node
	 */
	private AVLNode<E> rebalanceRight(AVLNode<E> localRoot)
	{
		//keep track of localRoot's right node
		AVLNode<E> rightNode = (AVLNode<E>)localRoot.right;
		
		//if the right node is right heavy
		if(rightNode.balance > AVLNode.BALANCED)
		{
			//the left node of the localRoot's right node
			AVLNode<E> rightLeftNode = (AVLNode<E>)rightNode.right;
			
			//if the rightLeft node is left heavy
			if(rightLeftNode.balance < AVLNode.BALANCED)
			{
				decrementBalance(rightLeftNode);
				decrementBalance(localRoot);
			}
			//if the rightLeft node is right heavy
			else if(rightLeftNode.balance > AVLNode.BALANCED)
			{
				incrementBalance(rightLeftNode);
				incrementBalance(rightNode);
			}
			
			//update the balance of the node
			incrementBalance(rightNode);
			
			//rotate the node right and update the balance
			localRoot.left = rotateRight(localRoot.left);
			decrementBalance(localRoot);
			decrementBalance(localRoot);
			
			//returns the left rotation about the originally given node
			return (AVLTree<E>.AVLNode<E>)rotateLeft(localRoot);
		}
		else
		{
			//update the balances
			decrementBalance(rightNode);
			decrementBalance(localRoot);
			decrementBalance(localRoot);
			
			//returns the left rotation about the originally given node
			return (AVLTree<E>.AVLNode<E>)rotateLeft(localRoot);
		}
	}
}
