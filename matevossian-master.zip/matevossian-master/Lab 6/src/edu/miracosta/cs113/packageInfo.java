/**
 * contains a drawn answer to Programming Exercise 2 section 2.5 on pg. 98 of the textbook
 * and answers to the self check exercises 1-5 section 2.5 pg 98
 */
/**
 * @author W7263477
 *
 */
package edu.miracosta.cs113;