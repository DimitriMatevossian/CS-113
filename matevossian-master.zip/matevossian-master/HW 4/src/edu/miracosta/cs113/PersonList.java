/** 
 * Contains a doubly linked list of Person objects
 */

package edu.miracosta.cs113;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.NoSuchElementException;

public class PersonList implements List<Person>
{
	private int size;
	private Node<Person> head = null;
	private Node<Person> tail = null;
	
	public PersonList()
	{
		size = 0;
	}
	
	//class representing a node on the linked list
	private static class Node<Person>
	{
		private Person data;
		private Node<Person> next = null;
		private Node<Person> prev = null;
		
		private Node(Person dataItem)
		{
			data = dataItem;
		}
	}
	
	//the iterator that will be attached to the list
	private class DoubleListIterator implements ListIterator<Person>
	{
		private Node<Person> nextItem;
		private Node<Person> lastItemReturned;
		private int index = 0;
		
		/**constructor for the iterator
		 * 
		 * @param i		the index representing the location on the list the iterator will initially be placed at
		 */
		public DoubleListIterator(int i)
		{
			//if the index is out of bounds
			//(negative or higher than size)
			if(i < 0 || i > size)
			{
				throw new IndexOutOfBoundsException("Invalid index " + i);
			}
			lastItemReturned = null;
			
			//if we are placing the iterator at the end of the list
			if(i == size)
			{
				index = size;
				nextItem = null;
				lastItemReturned = head;
				
				for(index = 1; index < size; index++)
				{
					lastItemReturned = lastItemReturned.next;
				}
			}
			else
			{
				//placing the iterator in the middle of the list
				nextItem = head;
				for(index = 0; index < i; index++)
				{
					lastItemReturned = nextItem;
					nextItem = nextItem.next;
				}
			}
		}

		/** adds a specified Person to the list
		 * 
		 * @param data		the person to be added
		 */
		@Override
		public void add(Person data)
		{
			Node<Person> newNode = new Node<Person>(data);
			
			//adding to an empty list
			if(size == 0)
			{
				head = newNode;
				lastItemReturned = newNode;
				nextItem = null;
			}
			else
			{
				//adding to the end
				if(index == size)
				{
					tail = newNode;
					newNode.next = null;
					newNode.prev = lastItemReturned;
					lastItemReturned.next = newNode;
					nextItem = null;
				}
				else
				{
					//adding to the middle or front
					newNode.next = nextItem;
					newNode.prev = nextItem.prev;
					nextItem.prev.next = newNode;
					nextItem.prev = newNode;
					lastItemReturned = newNode;
				}
			}
			
			size++;
			index++;
		}

		/**
		 *  returns a boolean representing whether or not there is a next element in the list
		 */
		@Override
		public boolean hasNext()
		{
			return nextItem != null;
		}

		/**
		 *  returns a boolean representing whether or not there is a previous element in the list
		 */
		@Override
		public boolean hasPrevious() {
			return nextItem.prev != null;
		}

		/**
		 *  moves the iterator forward one space, and returns the Person represented by the node that the iterator just moved over
		 */
		@Override
		public Person next()
		{	
			//if the list is empty, or we are at the end of the list
			if(size == 0 || index == size)
			{
				throw new NoSuchElementException("There are no elements to return");
			}
			
			lastItemReturned = nextItem;
			nextItem = nextItem.next;
			index++;
			return lastItemReturned.data;
		}

		/**
		 * returns the index that represents where the iterator would be if next() was called
		 */
		@Override
		public int nextIndex()
		{
			if(index == size)
			{
				return size;
			}
			return (index + 1);
		}

		/**
		 *  moves the iterator backward one space, and returns the Person represented by the node that the iterator just moved over
		 */
		@Override
		public Person previous() {
			//if the list is empty, or we are at the beginning of the list
			if(size == 0 || index == 0)
			{
				return null;
			}
			Node<Person> prevItem = nextItem.prev;
			
			lastItemReturned = prevItem;
			nextItem = prevItem;
			return lastItemReturned.data;
		}

		/**
		 * returns the index that represents where the iterator would be if previous() was called
		 */
		@Override
		public int previousIndex() 
		{
			return (index - 1);
		}

		/** removes the last node that the iterator moved over
		 * 
		 * precondition: can only be made after a call to next() or previous() has been made
		 */
		@Override
		public void remove()
		{
			if(size != 0)
			{
				if(size == 1)
				{
					head = null;
					size--;
				}
				else
				{
					Node<Person> prevNode = lastItemReturned.prev;
					nextItem.prev = prevNode;
					prevNode.next = nextItem;
					size--;
				}
			}
			
		}

		/** replaces the last node that the iterator went over with the specified value
		 * 
		 * precondition: This call can be made only if neither remove() nor add() have been called after the last call to next or previous.
		 * 
		 * @param data		the specified value to be added to the list after the removal
		 */
		@Override
		public void set(Person data)
		{	
			remove();
			
			next();
			previous();
			
			add(data);
		}
	}

	/** Add an item at the specified index the end of the list.
	 * @param data		The object to be inserted
	 * @throws IndexOutOfBoundsException
	 * 		if the index is our of range (i < 0 || i > size())
	 */
	@Override
	public boolean add(Person data) 
	{
		DoubleListIterator iter = new DoubleListIterator(size);
		iter.add(data);
		return true;
	}

	/** Add an item at the specified index.
	 * @param index		The index at which the object is to be inserted
	 * @param data		The object to be inserted
	 * @throws IndexOutOfBoundsException
	 * 		if the index is our of range (i < 0 || i > size())
	 */
	@Override
	public void add(int index, Person data)
	{
		DoubleListIterator iter = new DoubleListIterator(index);
		iter.add(data);
	}

	/**
	 * add functionality once I learn about Collections
	 * 
	 * @param c
	 * @return
	 */
	@Override
	public boolean addAll(Collection<? extends edu.miracosta.cs113.Person> c)
	{
		return false;
	}

	/**
	 * add functionality once I learn about Collections
	 * 
	 * @param c
	 * @return
	 */
	@Override
	public boolean addAll(int index, Collection<? extends edu.miracosta.cs113.Person> c) 
	{
		return false;
	}

	/** Removes all of the elements from this list (optional operation).
	 *  The list will be empty after this call returns.
	 * 
	 */
	@Override
	public void clear()
	{
		head = null;
		size = 0;
	}

	/**  Returns true if this list contains the specified element.
	 * 
	 * @param data	The target being searched for
	 * 
	 */
	@Override
	public boolean contains(Object o)
	{
		Person target = (Person)o;
		DoubleListIterator iter = new DoubleListIterator(0);
		
		do
		{
			if(target.equals(iter.next()))
			{
				return true;
			}
		} while(iter.hasNext());
		
		return false;
	}

	
	/**
	 * add functionality once I learn about Collections
	 * 
	 * @param c
	 * @return
	 */
	@Override
	public boolean containsAll(Collection<?> c)
	{
		return false;
	}

	/**	returns a person from the list at the specified index
	 * 
	 * @param index		the specified index at which to retrieve the Person
	 */
	@Override
	public Person get(int index)
	{
		DoubleListIterator iter = new DoubleListIterator(index);
		
		return iter.next();
	}

	/** returns the index of a Person in the list
	 *  returns -1 if the target was not found
	 *  
	 *  @param target	the Person being searched for in the list
	 */
	@Override
	public int indexOf(Object o)
	{
		Person target = (Person)o;
		DoubleListIterator iter = new DoubleListIterator(0);
		
		while(iter.hasNext())
		{
			if(target.equals(iter.next()))
			{
				if(iter.nextIndex() == size)
				{
					return iter.nextIndex() - 1;
				}
				else
				{
					return iter.nextIndex() - 2;
				}
			}
		}
		
		return -1;
	}

	/**
	 * returns a boolean representing whether or not the list is empty
	 */
	@Override
	public boolean isEmpty()
	{
		return size == 0 || head == null;
	}

	/**
	 * unnecessary because of the DoubleListIterator() method in the DoubleListIterator class
	 */
	@Override
	public Iterator<Person> iterator() 
	{
		return null;
	}

	/** returns the last found index of the specified target in the list
	 *  returns -1 if the target was not found
	 * 
	 * @param target	the Person being searched for in the list
	 */
	@Override
	public int lastIndexOf(Object o)
	{
		Person target = (Person)o;
		DoubleListIterator iter = new DoubleListIterator(0);
		int index = -1;
		
		while(iter.hasNext())
		{
			if(target.equals(iter.next()))
			{
				if(iter.nextIndex() == size)
				{
					index = iter.nextIndex() - 1;
				}
				else
				{
					index = iter.nextIndex() - 2;
				}
			}
		}
		
		return index;
	}

	/**
	 * unnecessary because of the DoubleListIterator() method in the DoubleListIterator class
	 */
	@Override
	public ListIterator<edu.miracosta.cs113.Person> listIterator()
	{
		return null;
	}

	/**
	 * unnecessary because of the DoubleListIterator() method in the DoubleListIterator class
	 */
	@Override
	public ListIterator<edu.miracosta.cs113.Person> listIterator(int index)
	{
		return null;
	}

	/** removes the first occurrence of the specified target in the list
	 * 
	 * @param target	the Person to be removed from the list
	 * 
	 * @return 			always returns true
	 * 
	 */
	@Override
	public boolean remove(Object o)
	{
		Person target = (Person)o;
		DoubleListIterator iter = new DoubleListIterator(0);
		
		while(iter.hasNext())
		{
			if(target.equals(iter.next()))
			{	
				iter.remove();
				return true;
			}
		}
		
		return true;
	}

	/** removes the Person at the specified index from the list
	 * 
	 * @param index		the index of the Person to be removed from the list
	 * 
	 * @return 			the removed Person
	 * 
	 */
	@Override
	public Person remove(int index)
	{
		DoubleListIterator iter = new DoubleListIterator(index);
		Person temp = iter.next();
		iter.remove();
		
		return temp;
	}

	/**
	 * add functionality once I learn about Collections
	 * 
	 * @param c
	 * @return
	 */
	@Override
	public boolean removeAll(Collection<?> c) 
	{
		return false;
	}

	/**
	 * add functionality once I learn about Collections
	 * 
	 * @param c
	 * @return
	 */
	@Override
	public boolean retainAll(Collection<?> c)
	{
		return false;
	}

	/** replaces the element at the specified position in the list with the specified element
	 * 
	 * @param index		index of the element to replace
	 * @param element	element to be stored at the specified position
	 * @return			the element previously at the specified position
	 */
	@Override
	public Person set(int index, Person element)
	{
		DoubleListIterator iter = new DoubleListIterator(index);
		Person temp = iter.next();	
		iter.set(element);
		
		return temp;
	}

	/**
	 * returns the size of the list
	 */
	@Override
	public int size()
	{
		return size;
	}

	/** returns a view of the portion of this list between the specified fromIndex, inclusive, and toIndex, exclusive.
	 * 
	 */
	@Override
	public List<Person> subList(int fromIndex, int toIndex)
	{
		DoubleListIterator iter = new DoubleListIterator(fromIndex);
		List<Person> personSubList = new PersonList();
		
		for(fromIndex = fromIndex; fromIndex < toIndex; fromIndex++)
		{
			personSubList.add(iter.next());
		}
		
		return personSubList;
	}

	/** Returns an array containing all of the elements in this list in proper sequence (from first to last element).
	 * 
	 */
	@Override
	public Object[] toArray() 
	{
		Object[] result = new Person[size];
		DoubleListIterator iter = new DoubleListIterator(0);
		
		for(int i = 0; i < size; i++)
		{
			result[i] = iter.next();
		}
		
		return result;
	}

	/**
	 * will add functionality once I learn about <T> T[]
	 */
	@Override
	public <T> T[] toArray(T[] a) 
	{
		return null;
	}
}