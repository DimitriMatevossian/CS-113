/**	A tester class to test the methods of the PersonList class
 * 
 * @author Dimitri Matevossian
 * @date   9/27/17
 * 
 * Algorithm:
 * - create a PersonList object
 * - add 4 dummy Person objects to the list
 * - print out the objects in the list to verify the additions
 * - add a Person object to the middle of the list
 * - print out the objects in the list to verify the additions
 * - remove an object from the middle of the list using its index
 * - print out the objects in the list to verify the removal
 * - remove an object from the list using another Person with the same values 
 * - print out the objects in the list to verify the removal
 * - Test the contains() method with a true and false case
 * - print out the results of the tests
 * - add a duplicate Person to the list
 * - print out the objects in the list to verify the addition
 * - print out the last index of the duplicate object to test the lastIndexOf() method
 * - print the results of the test
 * - check to see if the list is empty with the isEmpty() method
 * - print the results of the test (should be false)
 * - clear out the entire list using the clear() method
 * - check to see if the list is empty with the isEmpty() method
 * - print the results of the test (should be true)
 */

package edu.miracosta.cs113;

import java.util.List;

public class Tester 
{
	public static void main(String[] args)
	{
		PersonList myList = new PersonList();
		
		//add the test objects
		myList.add(new Person("John", 25));
		myList.add(new Person("Bill", 34));
		myList.add(new Person("Mary", 21));
		myList.add(new Person("Bob", 50));
		
		//print the list
		for(int i = 0; i < myList.size(); i++)
		{
			System.out.println(myList.get(i));
		}
		
		//add a Person to the middle of the list to test the add(int, Person) method
		myList.add(2, new Person("Jimmy", 13));
		
		//print the list
		System.out.println("\nAdding Jimmy to the middle");
		for(int i = 0; i < myList.size(); i++)
		{
			System.out.println(myList.get(i));
		}
		
		//remove someone from the list using the Person object's index
		myList.remove(2);
		
		System.out.println("\nRemoving the 2nd element of the list (counting up from 0)");
		
		//print the list
		for(int i = 0; i < myList.size(); i++)
		{
			System.out.println(myList.get(i));
		}
		
		//remove someone from the list using a Person object as reference
		myList.remove(new Person("Mary", 21));
		
		System.out.println("\nRemoving Mary from the list");
		
		//print the list
		for(int i = 0; i < myList.size(); i++)
		{
			System.out.println(myList.get(i));
		}
		
		//tests the contains() method for a true and a false case
		System.out.println("\nTesting the contains() method on John: " + myList.contains(new Person("John", 25)));
		System.out.println("\nTesting the contains(); method on Mark (is not in list): " + myList.contains(new Person("Mark", 66)));
		
		//tests the indexOf() method to find the index of John and Bob
		System.out.println("\nTesting the indexOf() method on John: " + myList.indexOf(new Person("John", 25)));
		System.out.println("\nTesting the indexOf() method on Bob: " + myList.indexOf(new Person("Bob", 50)) + "\n");
		
		//adding a duplicate person to test the lastIndexOf() method
		myList.add(new Person("John", 25));
		
		//print the list
		for(int i = 0; i < myList.size(); i++)
		{
			System.out.println(myList.get(i));
		}
		
		System.out.println("\nTesting the lastIndexOf() method on John: " + myList.lastIndexOf(new Person("John", 25)));
		
		//testing the clear() and isEmpty() method
		System.out.println("\nisEmpty test: " + myList.isEmpty());
		myList.clear();
		System.out.println("list cleared.");
		System.out.println("isEmpty test: " + myList.isEmpty());
	}
}
