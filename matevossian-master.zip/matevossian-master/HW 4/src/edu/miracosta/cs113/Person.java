/**
 * A dummy class to fill the PersonList
 */

package edu.miracosta.cs113;

public class Person 
{
	private String name;
	private int age;
	
	public Person()
	{
		name = null;
		age = 0;
	}
	
	public Person(String name, int age)
	{
		this.name = name;
		this.age = age;
	}
	
	public String getName()
	{
		return name;
	}
	
	public int getAge()
	{
		return age;
	}
	
	boolean equals(Person anotherPerson)
	{
		return anotherPerson.getName().equals(this.name) && anotherPerson.getAge() == this.age;
	}
	
	public String toString()
	{
		return "name: " + name + " age: " + age;
	}
}