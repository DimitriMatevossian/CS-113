/**
 * contains a class that implements the List interface in a doubly linked list
 * contains a class that tests the methods of the PersonList class
 */
/**
 * @author W7263477
 *
 */
package edu.miracosta.cs113;