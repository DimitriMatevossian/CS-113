/**
 * contains a class to test out the replace and delete methods from Programming exercises 1&2 on pg. 69 of the textbook
 */
/**
 * @author W7263477
 *
 */
package edu.miracosta.cs113;