/**
 * Driver.java: Tests out the replace and delete methods from Programming exercises 1&2 on pg. 69 of the textbook
 * 
 * @author W7263477
 * 
 * Algorithm:
 * - add a list of test Strings to the ArrayList
 * - print the initial ArrayList
 * - replace the word "book" with the word "screen"
 * - print the list again to confirm replacement
 * - delete the word "desert" from the list
 * - print the list again to confirm deletion
 * 
 */

package edu.miracosta.cs113;

import java.util.ArrayList;

public class Driver 
{
	public static void main(String[] args)
	{
		ArrayList<String> myList = new ArrayList<String>();
		
		//adding test Strings
		myList.add("book");
		myList.add("word");
		myList.add("desert");
		myList.add("tar");
		
		//print array
		printArrayList(myList);
		
		//replace the word "book" with the word "screen"
		replace(myList, "book", "screen");
		
		//print the list again to confirm replacement
		printArrayList(myList);
		
		//delete the word "desert" from the list
		delete(myList, "desert");
		
		//print the list again to confirm deletion
		printArrayList(myList);
	}
	
	/** Replaces each occurence of oldItem in aList with newItem. */
	public static void replace(ArrayList<String> aList, String oldItem, String newItem)
	{
		int index;
		
		while(aList.contains(oldItem))
		{
			index = aList.indexOf(oldItem);
			aList.set(index, newItem);
		}
	}
	
	/** Deletes the first occurrence of target in aList. */
	public static void delete(ArrayList<String> aList, String target)
	{
		int index = 0;
		boolean isRemoved = false;
		
		while(!isRemoved)
		{
			if(aList.get(index).equals(target))
			{
				aList.remove(index);
				isRemoved = true;
			}
			
			index++;
		}
	}
	
	/** Prints the contents of aList */
	public static void printArrayList(ArrayList<String> aList)
	{
		for(String element : aList)
		{
			System.out.print(element + " ");
		}
		
		System.out.println();
	}
}
