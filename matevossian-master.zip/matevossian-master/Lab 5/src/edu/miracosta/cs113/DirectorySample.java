package edu.miracosta.cs113;

import java.util.ArrayList;

public class DirectorySample 
{
	ArrayList<DirectoryEntry> theDirectory = new ArrayList<DirectoryEntry>();
	
	public DirectorySample()
	{
		
	}
	
	/** 
	 * constructor that fills theDirectory with test values
	 */
	public DirectorySample(boolean testing)
	{
		theDirectory.add(new DirectoryEntry("John Doe", "555-5555"));
		theDirectory.add(new DirectoryEntry("Jane Doe", "666-6666"));
		theDirectory.add(new DirectoryEntry("Bob Smith", "777-7777"));
		theDirectory.add(new DirectoryEntry("Ellen Brown", "888-8888"));
	}
	
	/** Add an entry to theDirectory or change an existing entry.
	 * @param aName The name of the person being added or changed
	 * @param newNumber The new number to be assigned
	 * @return The old number, or if a new entry, null
	 */
	public String addOrChangeEntry(String aName, String newNumber)
	{
		for(int index = 0; index < theDirectory.size(); index++)
		{
			if(theDirectory.get(index).getNumber().equals(newNumber))
			{
				String oldNumber = theDirectory.get(index).getNumber();
				theDirectory.set(index, new DirectoryEntry(aName, newNumber));
				return oldNumber;
			}
		}
		
		theDirectory.add(new DirectoryEntry(aName, newNumber));
		return null;
	}
	
	/** Remove an entry.
	 * @param aName The name of the person being removed
	 * @return The entry removed, or null if there is no entry for aName
	 */
	public DirectoryEntry removeEntry(String aName)
	{
		for(int index = 0; index < theDirectory.size(); index++)
		{
			if(theDirectory.get(index).getName().equals(aName))
			{
				DirectoryEntry temp = theDirectory.get(index);
				theDirectory.remove(index);
				return temp;
			}
		}
		
		return null;
	}
	
	public void printDirectory()
	{
		for(int index = 0; index < theDirectory.size(); index++)
		{
			System.out.println("Name: " + theDirectory.get(index).getName() + " Number: " + theDirectory.get(index).getNumber());
		}
	}
}
