/**
 * DirectoryDriver.java: Tests out the addOrChange and removeEntry methods from Programming exercises 1&2 on pg. 71 of the textbook
 * 
 * @author W7263477
 * 
 * Algorithm:
 * - create test directory
 * - print initial directory
 * - add an entry to the directory
 * - print to confirm add
 * - change an entry of the directory
 * - print to confirm change
 * - remove an entry of the directory
 * - print to confirm removal
 * 
 */

package edu.miracosta.cs113;

import java.util.ArrayList;

public class DirectoryDriver 
{
	public static void main(String[] args)
	{
		DirectorySample directory = new DirectorySample(true);
		
		//print initial directory
		directory.printDirectory();
		
		//testing the add function
		directory.addOrChangeEntry("Bob Ross", "111-1111");
		System.out.println("\nAdded Bob Ross, 111-1111\n");
		
		//print to confirm add
		directory.printDirectory();
		
		//testing the change function
		directory.addOrChangeEntry("Edward Mann", "666-6666");
		System.out.println("\nChanged Jane Doe to Edward Mann\n");
		
		//print to confirm the change
		directory.printDirectory();
		
		//testing the removeEntry method
		directory.removeEntry("Bob Smith");
		System.out.println("\nRemoved Bob Smith\n");
		
		//print to confirm the removal
		directory.printDirectory();
		
	}
}
