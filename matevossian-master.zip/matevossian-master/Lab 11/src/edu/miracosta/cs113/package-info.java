/**
 * Contains a step by step diagram of the numbers: 10, 14, 3, 6, 12, 13, 7, 4, 1, 2 being added to a heap
 * Contains a picture representing the final array of the heap
 */
/**
 * @author W7263477
 *
 */
package edu.miracosta.cs113;