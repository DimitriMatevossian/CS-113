/**
 * - Contains the MyEntry class, which is a class that implements the Entry interface
 * - Contains the HashtableChain class, which is a class that implements a Hash Table, using chaining to store its entries
 * - Contains a Tester class to test out the methods of the HashtableChain class
 */
/**
 * @author W7263477
 *
 */
package edu.miracosta.cs113;