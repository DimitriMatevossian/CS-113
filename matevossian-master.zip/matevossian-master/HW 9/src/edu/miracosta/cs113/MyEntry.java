/**
 * A Class that implements the Entry interface so that an Entry can be instantiated
 */

package edu.miracosta.cs113;

import java.util.Map;

public class MyEntry<K, V> implements Map.Entry<K, V>
{
	private K key;
	private V value;
	
	/**
	 * constructor for the MyEntry class that takes a key and a value
	 * 
	 * @param key	Key to create the entry with
	 * @param value	Value to create the entry with
	 */
	public MyEntry(K key, V value)
	{
		this.key = key;
		this.value = value;
	}

	/**
	 * returns the key
	 */
	@Override
	public K getKey() 
	{
		return key;
	}

	/**
	 * returns the value
	 */
	@Override
	public V getValue()
	{
		return value;
	}

	/**
	 * sets the current value to the given value and returns the old value
	 */
	@Override
	public V setValue(V value)
	{
		V oldValue = this.value;
		this.value = value;
		return oldValue;
	}
	
	
}
