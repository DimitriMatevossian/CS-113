/**
 * Tester.java - a tester class to test out the HashTableChain
 * 
 * @author 	Dimitri Matevossian
 * @date	11/17/17
 * 
 * Algorithm
 * - create two dummy HashtableChain objects
 * - fill one up past the initial capacity of 101 to test the rehash() method
 * - remove an entry
 * - print out the table to verify the results
 * - put two entries with different keys/values in the next table
 * - print out the specific entries using the get() method
 * - print out the result of a get call with a key that has not been added; should print out null
 */

package edu.miracosta.cs113;

public class Tester
{
	public static void main(String[] args)
	{
		HashtableChain<Integer, String> rehashTestTable = new HashtableChain<Integer, String>();
		HashtableChain<Integer, String> getterTestTable = new HashtableChain<Integer, String>();
		
		//testing the put and rehash
		for(int i = 0; i <= 104; i++)
		{
			rehashTestTable.put(i, "test");
		}
		
		//does not work
		//rehashTestTable.remove(11);
		
		//print to make sure the rehashed table has all of the correct values
		System.out.println(rehashTestTable);
		
		//testing for different keys with different values
		getterTestTable.put(5, "hello");
		getterTestTable.put(12, "please");
		
		//print the get results to make sure we are getting the correct values from the keys
		//print the value from a key that we didn't add to test for null
		System.out.println(getterTestTable.get(5) + "\n" + getterTestTable.get(12) + "\n" + getterTestTable.get(30));
	}
}
