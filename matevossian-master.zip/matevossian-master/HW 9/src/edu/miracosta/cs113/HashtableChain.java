/**
 * HashtableChain.java - a Hash Table data structure that fully implements the Map interface
 * 					   - uses chaining to store its entries
 */

package edu.miracosta.cs113;

import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

public class HashtableChain<K, V> extends AbstractMap<K, V>
{
	private LinkedList<Entry<K, V>>[] table;
	private int numKeys;
	private static final int CAPACITY = 101;
	private static final double LOAD_THRESHOLD = 3.0;
	
	/**
	 * constructor for the HashTableChain class that creates a new linked list of size CAPACITY
	 */
	public HashtableChain()
	{
		table = new LinkedList[CAPACITY];
	}
	
	/** Inner class to implement the set view. */
	private class EntrySet extends AbstractSet<Map.Entry<K,V>>
	{
		/**
		 * returns the size of the table
		 */
		@Override
		public int size()
		{
			return numKeys;
		}
		
		/**
		 * creates and returns a SetIterator
		 */
		@Override
		public Iterator<Map.Entry<K, V>> iterator()
		{
			return new SetIterator();
		}
	}
	
	/** 
	 * Iterator that can be used to iterate through the table
	 */
	private class SetIterator implements Iterator<Map.Entry<K,V>>
	{
		int index = 0;
		Iterator<Entry<K, V>> localIterator = null;
		
		/**
		 * checks to see if there is a next value in the Hash Table
		 * 
		 * @return	A boolean representing whether or not there is a next value in the Hash Table
		 */
		@Override
		public boolean hasNext()
		{
			if (localIterator != null)
			{
				if(localIterator.hasNext())
				{
					return true;
				}
				else
				{
					localIterator = null;
					index++;
				}
			}
			
			while (index < table.length && table[index] == null)
			{
				index++;
			}
			if (index == table.length)
			{
				return false;
			}
			
			localIterator = table[index].iterator();
			return localIterator.hasNext();
		}
		
		/**
		 * moves the SetIterator to the next non-null value in the table
		 * 
		 * @return The next entry, using Java's Iterator's next() method
		 */
		@Override
		public Map.Entry<K, V> next()
		{
			if(localIterator != null)
			{
				if(localIterator.hasNext())
				{
					return localIterator.next();
				}
			}
			
			return null;
		}


		/**
		 * removes the node that the Iterator is currently associated with
		 */
		@Override
		public void remove()
		{
			table[index].remove(index);
		}
	}
	
	/**
	 * creates and returns a new EntrySet
	 */
	@Override
	public Set<java.util.Map.Entry<K, V>> entrySet() 
	{
		return new EntrySet();
	}
	
	/**
	 * searches the table for an entry with the specified key and returns its value if found
	 * 
	 * @return	The value of the entry with the given key or null if no entry was found
	 */
	public V get(Object key)
	{
		int index = key.hashCode() % table.length;
		
		if(index < 0)
		{
			index += table.length;
		}
		if(table[index] == null)
		{
			return null;
		}
		
		for(SetIterator iter = new SetIterator(); iter.hasNext();)
		{
			Entry<K, V> current = iter.next();
			
			if(current.getKey().equals(key))
			{
				return current.getValue();
			}
		}
		
		return null;
	}
	
	/**
	 * inserts a new entry with the given key and value into the table if it does not exist already
	 * if there is already an entry with the given key, the entry's value will be replaced with the given value
	 * 
	 * @return	null if the given key was not found in the table or the replaced value if an entry with the given key was found
	 */
	public V put(K key, V value)
	{
		int index = key.hashCode() % table.length;
		if (index < 0)
		{
			index += table.length;
		}
		if (table[index] == null)
		{
			table[index] = new LinkedList<Entry<K, V>>();
		}
		
		for(SetIterator iter = new SetIterator(); iter.hasNext();)
		{
			Entry<K, V> current = iter.next();
			
			if(current.getKey().equals(key))
			{
				V oldValue = current.getValue();
				current.setValue(value);
				return oldValue;
			}
		}
		
		table[index].addFirst(new MyEntry<K, V>(key, value));
		numKeys++;
		
		if(numKeys > (LOAD_THRESHOLD * table.length))
		{
			rehash();
		}
		
		return null;
	}
	
	/**
	 * finds an entry with the given key and removes it from the table
	 * 
	 * @return	null if the entry with the given key was not found in the table or the value of that entry if it was found and removed
	 */
	public V remove(Object key)
	{
		int index = key.hashCode() % table.length;
		
		if(index < 0)
		{
			index += table.length;
		}
		if(table[index] == null)
		{
			return null;
		}
		
		for(SetIterator iter = new SetIterator(); iter.hasNext();)
		{
			Entry<K, V> current = iter.next();
			
			if(current.getKey().equals(key))
			{
				V removedValue = current.getValue();
				iter.remove();
				numKeys--;
				
				if(table[index].peekFirst() == null)
				{
					table[index] = null;
				}
				
				return removedValue;
			}
		}
		
		return null;
	}
	
	/**
	 * creates a new table of size 2n + 1 of the previous table (n being the size of the previous table)
	 * and reinserts all entries into the new table
	 */
	public void rehash()
	{
		int index;
		boolean hasAdded;
		
		LinkedList<Entry<K, V>>[] newTable = new LinkedList[table.length - 1];
		numKeys = 0;
		
		for(SetIterator iter = new SetIterator(); iter.hasNext();)
		{
			Entry<K, V> current = iter.next();
			hasAdded = false;
			
			index = current.getKey().hashCode() % newTable.length;
			if (index < 0)
			{
				index += newTable.length;
			}
			if (newTable[index] == null)
			{
				newTable[index] = new LinkedList<Entry<K, V>>();
			}
			
			for(Entry<K, V> nextItem : newTable[index])
			{
				if (nextItem.getKey().equals(current.getKey()))
				{
					nextItem.setValue(current.getValue());
					hasAdded = true;
				}
			}
			if(!hasAdded)
			{
				newTable[index].addFirst(current);
				numKeys++;
			}
		}
	}
	
	/**
	 * @return	A string containing all the entries in the table in the format "key = value\n" for every entry in the table
	 */
	public String toString()
	{
		String result = "";
		
		for(SetIterator iter = new SetIterator(); iter.hasNext();)
		{
			Entry<K, V> current = iter.next();
			
			result += current.getKey().toString() + " = " + current.getValue().toString() + "\n";
		}
		
		return result;
	}
}